@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Abert TV - Guncelle ve Kur
set "URL=https://github.com/abert84tv/abert-tv-launcher/releases/download/latest/abert-tv.apk"
set "PKG=com.abert.tv"

if not exist adb.exe (
  echo adb.exe bulunamadi. Bu dosyayi platform-tools klasorunun icine koy ve tekrar calistir.
  pause
  exit /b 1
)

echo.
echo  ABERT TV - GUNCELLE VE KUR
echo  --------------------------
echo  1) GitHub'a yeni proje.zip yukledin ve Actions'ta yesil tik gordun.
echo  2) TV'de Ayarlar ^> Cihaz tercihleri ^> Gelistirici secenekleri ^>
echo     Kablosuz hata ayiklama ACIK. Ana ekranda IP adresi ve port yazar.
echo.

set "SON="
if exist son-adres.txt set /p SON=<son-adres.txt
set "ADRES="
set /p ADRES=TV adresi, sadece sayilar (ornek 192.168.1.110:41873) [%SON%] : 
if "%ADRES%"=="" set "ADRES=%SON%"
if "%ADRES%"=="" (
  echo Adres girmedin.
  pause
  exit /b 1
)
> son-adres.txt echo %ADRES%

echo.
echo [1/5] Yeni surum indiriliyor...
curl.exe -L --fail -s -o abert-tv.apk "%URL%"
if errorlevel 1 (
  echo Indirme basarisiz. Interneti ve GitHub derlemesinin bittigini kontrol et.
  pause
  exit /b 1
)

echo [2/5] TV'ye baglaniliyor...
adb connect %ADRES% >nul
adb -s %ADRES% get-state >nul 2>&1
if errorlevel 1 (
  echo Baglanilamadi. Port degismis olabilir veya eslestirme gerekiyor.
  set /p ESL=Eslestirme yapmak ister misin? E veya H : 
  if /i "!ESL!"=="E" (
    set /p PADR=TV'deki "Eslestirme koduyla cihazi eslestir" ekranindaki adres IP:port : 
    adb pair !PADR!
    adb connect %ADRES% >nul
  )
  adb -s %ADRES% get-state >nul 2>&1
  if errorlevel 1 (
    echo Hala baglanilamadi. TV'deki guncel IP:port'u kontrol edip tekrar dene.
    pause
    exit /b 1
  )
)

echo [3/5] Kuruluyor (profillerin ve ayarlarin silinmez)...
adb -s %ADRES% install -r abert-tv.apk
if errorlevel 1 (
  echo Kurulum basarisiz. Yukaridaki hata satirini bana gonder.
  pause
  exit /b 1
)

echo.
echo [4/5] Koruma servisi (cocuk profili ve Ana Sayfa tusu icin gerekli)
for /f "delims=" %%i in ('adb -s %ADRES% shell settings get secure enabled_accessibility_services') do set "CUR=%%i"
echo !CUR! | find "KidsGuardService" >nul
if not errorlevel 1 (
  echo Koruma servisi zaten acik.
) else (
  set /p KS=Koruma servisi acilsin mi? E veya H : 
  if /i "!KS!"=="E" (
    if "!CUR!"=="null" (
      set "NEW=%PKG%/%PKG%.KidsGuardService"
    ) else (
      set "NEW=!CUR!:%PKG%/%PKG%.KidsGuardService"
    )
    adb -s %ADRES% shell settings put secure enabled_accessibility_services !NEW!
    adb -s %ADRES% shell settings put secure accessibility_enabled 1
    echo Koruma servisi acildi.
  )
)

echo.
echo [5/5] Ekran koruyucu izni (Aerial Views gibi bir ekran koruyucu secmek icin bir kereye mahsus)
set /p EK=Izin verilsin mi? E veya H : 
if /i "!EK!"=="E" (
  adb -s %ADRES% shell pm grant %PKG% android.permission.WRITE_SECURE_SETTINGS
  echo Izin verildi.
)

adb disconnect %ADRES% >nul 2>&1
echo.
echo Bitti. TV'de Kablosuz hata ayiklamayi kapatabilirsin.
echo Surumu kontrol et: Ayarlar ^> Sistem ve kurulum ^> Uygulama surumu.
pause
