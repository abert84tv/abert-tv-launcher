import com.abert.tv.PressMachine
// Sanal saat: zamanlanmış işleri sırayla çalıştırır
class Clock { var t = 0L; val q = ArrayList<Pair<Long, () -> Unit>>()
  fun sched(ms: Long, j: () -> Unit) { q.add(Pair(t + ms, j)) }
  fun adv(ms: Long) { val end = t + ms; while (true) { val n = q.filter { it.first <= end }.minByOrNull { it.first } ?: break; q.remove(n); t = n.first; n.second() }; t = end } }
var pass = 0; var fail = 0
fun ok(c: Boolean, m: String) { if (c) { pass++; println("OK   $m") } else { fail++; println("FAIL $m") } }
fun run(name: String, s: Boolean, l: Boolean, d: Boolean, script: (PressMachine, Clock) -> Unit): List<String> {
  val c = Clock(); val out = ArrayList<String>()
  val m = PressMachine({ ms, j -> c.sched(ms, j) }) { t, _ -> out.add(t) }
  script(m, c); c.adv(2000); return out }
fun main() {
  // yalnız kısa: beklemeden
  var o = run("k", true, false, false) { m, c -> m.down(1, 0, true, false, false); m.up(1, true, false) }
  ok(o == listOf("short"), "P1 yalnız kısa atama anında çalışır: $o")
  // kısa + uzun: kısa basış
  o = run("kl", true, true, false) { m, c -> m.down(1, 0, true, true, false); c.adv(200); m.up(1, true, false) }
  ok(o == listOf("short"), "P2 kısa+uzun: kısa basış: $o")
  // kısa + uzun: uzun basış
  o = run("kl", true, true, false) { m, c -> m.down(1, 0, true, true, false); c.adv(700); m.up(1, true, false) }
  ok(o == listOf("long"), "P3 kısa+uzun: uzun basış yalnız uzunu çalıştırır: $o")
  // kısa + çift: tek basış bekler sonra kısa
  o = run("kd", true, false, true) { m, c -> m.down(1, 0, true, false, true); c.adv(80); m.up(1, true, true) }
  ok(o == listOf("short"), "P4 kısa+çift: tek basış 320 ms sonra kısa: $o")
  // kısa + çift: çift basış
  o = run("kd", true, false, true) { m, c -> m.down(1, 0, true, false, true); c.adv(80); m.up(1, true, true); c.adv(120); m.down(1, 0, true, false, true); c.adv(60); m.up(1, true, true) }
  ok(o == listOf("double"), "P5 çift basış yalnız çifti çalıştırır: $o")
  // üçü birden: uzun
  o = run("kld", true, true, true) { m, c -> m.down(1, 0, true, true, true); c.adv(700); m.up(1, true, true) }
  ok(o == listOf("long"), "P6 üçlü: uzun: $o")
  // üçü birden: iki yavaş basış = iki kısa
  o = run("kld", true, true, true) { m, c -> m.down(1, 0, true, true, true); c.adv(80); m.up(1, true, true); c.adv(500); m.down(1, 0, true, true, true); c.adv(80); m.up(1, true, true) }
  ok(o == listOf("short", "short"), "P7 iki yavaş basış iki kısa sayılır: $o")
  // bekleyen kısa, başka tuşa basılınca kaybolmaz
  o = run("x", true, false, true) { m, c -> m.down(1, 0, true, false, true); m.up(1, true, true); c.adv(50); m.interrupt() }
  ok(o == listOf("short"), "P8 başka tuşa basılınca bekleyen kısa hemen çalışır: $o")
  // tekrar eden (basılı tutulan) tuş olayları yok sayılır
  o = run("r", true, true, false) { m, c -> m.down(1, 0, true, true, false); for (i in 1..6) { c.adv(100); m.down(1, i, true, true, false) }; m.up(1, true, false) }
  ok(o == listOf("long"), "P9 basılı tutma tekrarları tek uzun basış: $o")
  // yalnız çift atanmışsa tek basış hiçbir şey yapmaz
  o = run("d", false, false, true) { m, c -> m.down(1, 0, false, false, true); m.up(1, false, true) }
  ok(o.isEmpty(), "P10 yalnız çift atanmış tuşta tek basış boş geçer: $o")
  println("toplam: $pass geçti, $fail kaldı")
}
