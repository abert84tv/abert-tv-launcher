import com.abert.tv.ui.*
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

val MIC = "M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"
val BELL = "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"
val GEAR = "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"

fun app(id: String, name: String, color: Long, g: String) = Tile(id, name, "", Col.parse("#" + color.toString(16).padStart(6, '0')), g, 0)
val TV = app("tv", "Canlı TV", 0x4C8DAE, "TV"); val YT = app("yt", "YouTube", 0xE5392F, "Y"); val YK = app("yk", "YouTube Kids", 0xF2812E, "Y")
val TM = app("tm", "TiviMate", 0x6B5BD6, "T"); val TZ = app("tz", "Televizo", 0x2E9E9E, "T"); val BR = app("br", "Tarayıcı", 0x6B7788, "B"); val SK = app("sk", "Sesli Kitap", 0x2FA58F, "S")

fun cont(t: String, a: String, c: Long, p: Int) = Tile("c" + t, t, a, Col.parse("#" + c.toString(16).padStart(6, '0')), "", 1, p)
fun link(n: String, s: String, c: Long) = Tile("l" + n, n, s, Col.parse("#" + c.toString(16).padStart(6, '0')), "", 3)
fun fold(n: String, apps: List<Tile>) = Tile("f" + n, n, apps.size.toString() + " uygulama", apps[0].color, "", 2, 0, apps.take(4).map { Pair(it.color, it.glyph) })

fun adult(light: Boolean, fr: Int, fc: Int): HomeScene {
    val top = listOf(TopIcon("Sesli arama", "Google asistanı", MIC), TopIcon("Bildirimler", "2 yeni bildirim", BELL, 2),
        TopIcon("Ayarlar", "Profiller, ana ekran, tuşlar, sistem", GEAR), TopIcon("Profil", "Hızlı panel", "", 0, "A", Col.parse("#1F8F7A")))
    val rows = listOf(
        Row("Devam et", listOf(cont("Dizi: 3. Bölüm", "YouTube · %42", 0xE5392F, 42), cont("Kanal kaydı", "TiviMate", 0x6B5BD6, 0), cont("Çizgi film", "YouTube Kids · %70", 0xF2812E, 70))),
        Row("Son kullanılanlar", listOf(TM, YT)),
        Row("Haber", listOf(TM, TZ, TV)),
        Row("Klasörler", listOf(fold("Videolar", listOf(YT, BR, YK)), fold("Çocuk", listOf(YK, SK)))),
        Row("Tüm uygulamalar", listOf(TV, YK, YT, TM, TZ, BR, SK)),
        Row("Araçlar", listOf(link("Hızlı panel", "Uyku, rahatsız etme", 0x1F8F7A), link("Google TV ana ekranı", "60 sn açık kalır", 0x6B5BD6)))
    )
    val s = HomeScene(HomeData("İyi günler, Abert · 2 yeni bildirim", "27 Ekim Salı 18:42", top, rows, light, 1, true, 1, 1f)); s.fr = fr; s.fc = fc; return s
}

fun kids(): HomeScene {
    val top = listOf(TopIcon("Ayarlar", "Şifre ile açılır", GEAR), TopIcon("Profil", "Kim izliyor?", "", 0, "E", Col.parse("#F2A93B")))
    val rows = listOf(Row("Senin uygulamaların", listOf(YK, TZ, TM)), Row("Benim ayarlarım", listOf(link("Uygulamaları sırala", "Sırayı sen belirle", 0x2D7FD6))))
    val s = HomeScene(HomeData("Merhaba Elif!", "27 Ekim Salı 18:42", top, rows, false, 1, true, 0, 1f)); s.fr = 1; s.fc = 0; return s
}

fun easy(): HomeScene {
    val top = listOf(TopIcon("Ayarlar", "Şifre ile açılır", GEAR), TopIcon("Profil", "Kim izliyor?", "", 0, "D", Col.parse("#2D7FD6")))
    val rows = listOf(Row("Tüm uygulamalar", listOf(TV, YT, TM)), Row("Yardım", listOf(link("Sesli arama", "Konuşarak ara", 0x2D7FD6))))
    val s = HomeScene(HomeData("İyi günler, Dede", "27 Ekim Salı 18:42", top, rows, false, 3, false, 0, 1.5f)); s.fr = 1; s.fc = 0; return s
}

fun render(sc: HomeScene, out: String) {
    val img = BufferedImage(1920, 1080, BufferedImage.TYPE_INT_ARGB)
    val g = JavaGfx(img); sc.draw(g, 1920, 1080); g.dispose()
    ImageIO.write(img, "png", File(out))
}

fun main() {
    System.setProperty("java.awt.headless", "true")
    render(adult(false, 1, 0), "/tmp/n1_adult_dark.png")
    render(adult(false, 3, 1), "/tmp/n1_adult_row3.png")
    render(adult(false, 4, 0), "/tmp/n1_adult_fold.png")
    render(adult(true, 1, 0), "/tmp/n1_adult_light.png")
    render(adult(false, 0, 2), "/tmp/n1_adult_gear.png")
    render(kids(), "/tmp/n1_kids.png")
    render(easy(), "/tmp/n1_easy.png")
    println("render tamam")
}
