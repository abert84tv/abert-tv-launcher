import com.abert.tv.ui.*
import java.awt.*
import java.awt.geom.*
import java.awt.image.BufferedImage
import java.io.File

/** Test amaçlı: sahneyi bilgisayarda (Java2D) çizer. Uygulamaya girmez. */
class JavaGfx(val img: BufferedImage) : Gfx {
    private val g2: Graphics2D = img.createGraphics()
    private class St(val tf: AffineTransform, val clip: Shape?, val alpha: Float)
    private val stack = ArrayList<St>()
    private var am = 1f
    private val fonts = HashMap<Int, Font>()

    init {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON)
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE)
        fonts[300] = Font.createFont(Font.TRUETYPE_FONT, File("/tmp/inter-light.ttf"))
        fonts[400] = Font.createFont(Font.TRUETYPE_FONT, File("/tmp/inter-regular.ttf"))
        fonts[600] = Font.createFont(Font.TRUETYPE_FONT, File("/tmp/inter-semibold.ttf"))
    }

    private fun col(c: Int, extra: Float = 1f): Color =
        Color(Col.r(c), Col.g(c), Col.b(c), (Col.a(c) * am * extra).toInt().coerceIn(0, 255))

    override fun save() { stack.add(St(g2.transform, g2.clip, am)) }
    override fun restore() { val s = stack.removeAt(stack.size - 1); g2.transform = s.tf; g2.clip = s.clip; am = s.alpha }
    override fun translate(dx: Float, dy: Float) { g2.translate(dx.toDouble(), dy.toDouble()) }
    override fun scale(sx: Float, sy: Float) { g2.scale(sx.toDouble(), sy.toDouble()) }
    override fun alpha(a: Float) { am *= a }
    override fun clipRect(x: Float, y: Float, w: Float, h: Float) { g2.clip(Rectangle2D.Float(x, y, w, h)) }
    override fun fillRect(x: Float, y: Float, w: Float, h: Float, color: Int) { g2.paint = col(color); g2.fill(Rectangle2D.Float(x, y, w, h)) }
    override fun fillRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int) { g2.paint = col(color); g2.fill(RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2)) }
    override fun fillRRectGrad(x: Float, y: Float, w: Float, h: Float, r: Float, top: Int, bottom: Int) {
        g2.paint = GradientPaint(x, y, col(top), x, y + h, col(bottom))
        g2.fill(RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2))
    }
    override fun strokeRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int, sw: Float) {
        g2.paint = col(color); g2.stroke = BasicStroke(sw)
        g2.draw(RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2))
    }
    override fun fillCircle(cx: Float, cy: Float, r: Float, color: Int) { g2.paint = col(color); g2.fill(Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2)) }
    override fun glow(cx: Float, cy: Float, r: Float, color: Int) {
        val c0 = col(color); val c1 = Color(c0.red, c0.green, c0.blue, 0)
        g2.paint = RadialGradientPaint(cx, cy, r, floatArrayOf(0f, 1f), arrayOf(c0, c1))
        g2.fill(Rectangle2D.Float(cx - r, cy - r, r * 2, r * 2))
    }
    private fun font(weight: Int, size: Float): Font = (fonts[weight] ?: fonts[400]!!).deriveFont(size)
    override fun text(s: String, x: Float, y: Float, size: Float, color: Int, weight: Int, align: Int) {
        g2.font = font(weight, size); g2.paint = col(color)
        val w = g2.fontMetrics.stringWidth(s)
        val dx = when (align) { 1 -> -w / 2f; 2 -> -w.toFloat(); else -> 0f }
        g2.drawString(s, x + dx, y)
    }
    override fun measure(s: String, size: Float, weight: Int): Float {
        g2.font = font(weight, size); return g2.fontMetrics.stringWidth(s).toFloat()
    }
    override fun icon(cmds: List<PathCmd>, x: Float, y: Float, size: Float, color: Int) {
        val p = Path2D.Float(Path2D.WIND_NON_ZERO)
        for (c in cmds) when (c) {
            is PathCmd.M -> p.moveTo(c.x, c.y)
            is PathCmd.L -> p.lineTo(c.x, c.y)
            is PathCmd.C -> p.curveTo(c.x1, c.y1, c.x2, c.y2, c.x, c.y)
            is PathCmd.Z -> p.closePath()
        }
        val at = AffineTransform(); at.translate(x.toDouble(), y.toDouble()); at.scale(size / 24.0, size / 24.0)
        g2.paint = col(color); g2.fill(at.createTransformedShape(p))
    }
    fun dispose() { g2.dispose() }
}
