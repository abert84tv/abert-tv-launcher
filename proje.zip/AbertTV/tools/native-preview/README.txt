Yerel ana ekranın (ui/ klasörü) bilgisayarda ekran görüntüsü alma düzeneği. Uygulamaya girmez.
Derleme (Kotlin derleyicisi gerekir):
  kotlinc app/src/main/java/com/abert/tv/ui/Gfx.kt app/src/main/java/com/abert/tv/ui/SvgPath.kt app/src/main/java/com/abert/tv/ui/HomeScene.kt tools/native-preview/JavaGfx.kt tools/native-preview/Render.kt -include-runtime -d n1.jar
  java -Djava.awt.headless=true -cp n1.jar RenderKt
Yazı tipi dosyaları /tmp/inter-light.ttf, /tmp/inter-regular.ttf, /tmp/inter-semibold.ttf yolunda beklenir.
