# Abert TV 2.0 (Google TV / Android TV ana ekranı)

Reklamsız, internet izni olmayan, herkes için (yetişkin, çocuk, yaşlı) profilli ana ekran.
Bu sürüm TCL Google TV için hazırlandı, henüz **gerçek TV'de denenmedi**. Aşağıdaki test listesiyle birlikte deneyeceğiz.

## 2.11'de yeni
- **Tuş atamada kısa, uzun ve çift basış:** Aynı tuşa üçü birden atanabilir. Uzun veya çift basış da atanmış tuşta kısa basış yaklaşık 0,3 sn bekleyerek çalışır; yalnız kısa basış atanmışsa hiç beklemez. Atanmış tuşun eski işlevi yerine yeni işlev çalışır; yön, OK ve Geri hiçbir zaman atanamaz.
- **Profile göre tuş atama:** Her atama "Herkes" veya tek bir profil için olabilir; profile özel atama aynı tuştaki genel atamanın önüne geçer. Çocuk profilinde tuş atama hiç çalışmaz.
- **Hızlı panel düzeni:** Ayarlar > Hızlı panel: öğeleri göster/gizle ve sırala.
- **Yedekleme ve geri yükleme:** Ayarlar > Yedekleme ve geri yükleme. Her gün otomatik yedek, son 5 yedek tutulur; "Şimdi yedekle" ayrıca `Download/AbertTV` klasörüne kopya bırakır. Geri yüklemeden önce mevcut ayarlar da yedeklenir (geri alınabilir). Şifre, kurtarma kodu ve duvar kağıdı dosyası yedeğe girmez.
  - Uygulamayı **kaldırırsan** uygulama içindeki yedekler silinir. Yeniden kurduktan sonra yedeği şu komutla geri ekle, sonra listeden seç ("ADB ile eklenen"):
    `adb push abert-tv-yedek.json /sdcard/Android/data/com.abert.tv/files/`
  - Güncellemeyi her zaman `adb install -r` ile yap; böylece hiçbir şey silinmez.
- **İmza anahtarı güvenliği:** En kolay yol GitHub deposunu **gizli (Private)** yapmak: depo > Settings > General > en altta "Change visibility" > Private. Derleme ve indirme aynen çalışır (indirirken GitHub'a giriş yapmış olman yeter). İstersen kendi anahtarını GitHub Secrets'a da koyabilirsin (`ABERT_KEYSTORE_B64`, `ABERT_KS_PASS`, `ABERT_KS_ALIAS`, `ABERT_KEY_PASS`); ancak anahtar değişirse uygulamayı bir kez kaldırıp kurman gerekir, önce yedek al.

## 2.10'da yeni
- **Şifre girme ekranı:** Varsayılan Google TV tarzı kumanda halkası: halkada bir satırın üç rakamı görünür; sol tuş soldakini, OK ortadakini, sağ tuş sağdakini girer; yukarı/aşağı satır değiştirir (1 2 3, 4 5 6, 7 8 9, 0). Geri tuşu son rakamı siler; kumandanın rakam tuşları da çalışır. En üst satırda yukarı basınca "Rakamları gizle/göster" ve "Yardım" düğmelerine çıkılır; rakam listesini gizleme tercihi kalıcıdır. Ayarlar > Şifre girme ekranı ile tuş takımına geçebilirsin; seçim kalıcıdır.
- **Şifremi unuttum:** Şifre belirlenince (veya Ayarlar > Kurtarma kodu ile) **8 haneli kurtarma kodu** bir kez gösterilir; kâğıda yaz. Şifre ekranında "Şifremi unuttum" ile bu kodu girip yeni şifre belirlersin; ardından yeni bir kurtarma kodu verilir, eskisi geçersiz olur. Kodun yalnızca özeti saklanır; 5 yanlış denemede artan bekleme başlar. Kod yoksa tek yol verileri sıfırlamaktır: `adb shell pm clear com.abert.tv`.
- **Duvar kağıdı:** Ayarlar > Duvar kağıdı > TV'den seç. Resim, GIF veya en çok 60 saniyelik video (80 MB'a kadar). Dosyayı TV'ye USB bellekle ya da telefondan dosya gönderme uygulamasıyla at. İlk seferde sistem medya izni ister. Seçilen dosya uygulamanın kendi klasörüne kopyalanır. Karartma ayarı yazıların okunmasını sağlar. Video duvar kağıdı TV'yi biraz daha yorar.
- **Ekran koruyucu:** Play Store'dan bir ekran koruyucu indir (ör. Aerial Views), Ayarlar > Ekran koruyucu'dan seç. Google TV, üçüncü taraf ekran koruyucuyu kendi ayarlarında seçtirmediği için **bir kez** bilgisayardan şu izin gerekir:
  `adb shell pm grant com.abert.tv android.permission.WRITE_SECURE_SETTINGS`
  Bu komut hiçbir şeyi kapatmaz; Abert TV yalnızca ekran koruyucu ayarını yazar. TV kendi ekran koruyucusuna döndürürse Abert TV her açılışta seçimini geri yükler. "TV'nin kendi ekran koruyucusuna dön" ile eski haline dönersin.

## ÖNEMLİ: güvenli kurulum sırası (Aşama 1)
Bu uygulama, hiçbir sistem uygulamasını kapatmadan çalışacak şekilde tasarlandı. Kurallar:
1. **Google'ın hiçbir uygulamasını devre dışı bırakma.** `pm disable`, `pm disable-user`, `pm uninstall` komutlarını çalıştırma; başka bir yapay zekâdan veya siteden gelen komutları da önce bana göster. Google ana ekranı kapatılırsa TV yeniden başlama ve siyah ekran döngüsüne girebilir.
2. **Önce yalnızca ana ekran olarak dene.** Kurduktan sonra erişilebilirlik, bildirim ve tuş servislerini AÇMA. Uygulama Abert TV simgesinden açılır; Ana Sayfa tuşu Google'ın ekranına gider, bu bu aşamada normaldir.
3. Servisleri ancak bir gün sorunsuz kullandıktan sonra, tek tek ve benimle birlikte aç.
4. Bir şey ters giderse: Ayarlar > Uygulamalar > Abert TV > Kaldır. Başka bir şey yapmana gerek yok.
5. Kurulum: Google Play Protect, erişilebilirlik ve bildirim erişimi isteyen uygulamaları internetten kurulumda engelleyebilir; bu durumda `adb install -r abert-tv.apk` ile kur. Kurulumdan sonra TV'de Kablosuz hata ayıklamayı kapat.

## Bu sürümde olanlar
- **3 profil türü:** Yetişkin, Çocuk, Kolay (yaşlılar için sade ekran). En fazla 6 profil.
- **Uyanınca "Kim izliyor?":** 2 veya daha fazla profil varsa TV her açıldığında/uykudan uyandığında profil seçimi gelir. Tek profil varsa doğrudan ana ekran.
- **Şifre:** Yetişkin profiline girmek için 4 haneli şifre (profil seçimi varken). Yanlış denemede artan süreyle kilitlenir.
- **Çocuk profili:** yalnızca onaylı uygulamalar, günlük süre sınırı, bonus süre, uyarı bildirimleri (10 dk ve 1 dk kala), izinsiz uygulama anında geri atılır.
- **Kategoriler (ana ekran satırları):** Ayarlar > Ana ekran düzeni ve görünüm > Kategoriler: istediğin kadar (12'ye kadar) kategori ekle, içine istediğin uygulamaları koy; bir uygulama birden fazla kategoride olabilir. Ana ekranda uygulamaya **uzun basarak** (Tamam tuşunu yarım saniye basılı tut) kategoriye ekle, kategoride sola/sağa taşı, kategoriden çıkar veya gizle. Kategoriler profil başınadır ve yalnızca yetişkin değiştirir.
- **Uygulama simgeleri menülerde:** uygulama seçilen her menüde (izinli uygulamalar, gizli uygulamalar, kategoriye ekleme, tuş atama, yönlendirme) ve klasör kutucuklarında uygulamanın kendi simgesi veya afişi görünür.
- **Menülerde "Geri/Bitti/Kapat" satırı yok:** Geri tuşu zaten kapatır ve değişiklikler anında uygulanır.
- **Klasör veya satır:** her kategori için "Görünüm" seçeneği: Satır (ana ekranda ayrı satır) veya Klasör ("Klasörler" satırında tek kutucuk, açınca cam panelde uygulamalar). Çok kategorin varsa seyrek kullandıklarını klasöre koy.
- **Klasörün yanında tek uygulama:** ana ekranda uygulamaya uzun bas > **Favorilere sabitle**. Sabitlenen uygulamalar "Klasörler ve favoriler" satırında klasörlerin yanında tek kutucuk olarak görünür (klasör yoksa satırın adı "Favoriler").
- **Son kullanılanlar:** her profil kendi açtığı uygulamaları görür (cihazda tutulur, "temizle" ile silinir).
- **Devam et (yarıda kalanlar):** sistemin "sıradaki / devam et" listesini gösterir; bu profilin görebildiği uygulamalara göre süzülür. İzin ister (Ayarlar > Ana ekran düzeni > Devam et satırı). Sınırları: bu liste cihaz genelinde tektir, kişi bazlı değildir (aynı uygulamayı iki kişi kullanıyorsa karışır); yalnızca listeye kayıt yapan uygulamalar görünür (internet izni olmadığı için kapak resimleri yerine başlık ve ilerleme çubuğu gösterilir).
- **Çocuk uyku saati:** belirlenen saatlerde çocuk profili kilitlenir (Profiller > çocuk profili > Uyku saati).
- **Güvenli mod:** launcher kısa sürede üst üste çökerse Ana Sayfa devralmayı kapatıp Google ana ekranına döner.
- **Ana ekran düzeni ve görünüm (profil başına):** kutucuk boyutu (satırda 6/5/4/3), uygulama adları, büyük başlık alanı, menü şeffaflığı, hareket (tam/azaltılmış/yok), yazı boyutu (%175'e kadar), kalın yazı, belirgin odak, satır seçimi (Devam et, Son kullanılanlar, Tüm uygulamalar), gizli uygulamalar.
- **Çocuk profilinde uygulama sırası:** çocuk "Uygulamaları sırala" ile kendi sırasını belirler (Yukarı/Aşağı). Sıralama hiçbir uygulamayı ekleyemez veya silemez; **uygulamayı profilden kaldırmak ebeveyn şifresi ister**.
- **Kolay profil:** büyük kutucuklar, az uygulama, büyük/kalın yazı, belirgin odak çerçevesi, az hareket, büyük "Sesli arama". Ayarlar şifreli. İstersen girişte de şifre.
- **Profil bazlı erişilebilirlik:** yazı boyutu (%100/125/150), kalın yazı, belirgin odak çerçevesi, az hareket.
- **Ana Sayfa devralma:** Ana Sayfa tuşuyla Google TV'nin kendi (reklamlı) ana ekranı açılırsa otomatik bu ekrana döner. Profil seçici gibi Google TV pencerelerine dokunmaz. "Google TV ana ekranı" kutusu onu 60 sn açık bırakır.
- **Oyun kolu (DualSense, Xbox):** yön tuşu ve sol analog gezinme, Çarpı = seç, Daire = geri, Kare veya Options = hızlı panel, Üçgen = sesli arama, L1/R1 = satır değiştirme.
- **Sesli arama:** Google'ın asistanını açar (kendi sesli asistanımız yok). Kumandanın mikrofon tuşu zaten sistemde çalışır.
- **Klavye ve mikrofon:** profil adı gibi yazı girişlerinde sistemin klavyesi açılır; klavyedeki mikrofon düğmesiyle sesle yazılabilir. Telefonun klavyesi de kullanılabilir (aşağıda).
- **Bildirim merkezi (yetişkin):** kendi bildirimlerimiz (süre uyarıları, uyku, eski güvenlik yaması) her zaman çalışır. Başka uygulamaların bildirimleri için "Bildirim erişimi" izni gerekir (isteğe bağlı). Zil sayacı, en yeni önde, OK ile aç, Kapat ile sil, Rahatsız Etme, "içeriği göster" (varsayılan kapalı). Hepsi bellekte, diske yazılmaz.
- **Sistem kısayolları (hızlı panel):** Wi-Fi, Bluetooth, görüntü, ses, uygulamalar ve depolama ayar ekranlarına tek yerden kısayol (yalnızca yetişkin). Android'in vermediği hiçbir yetki zorlanmaz.
- **Hızlı panel:** uyku zamanlayıcı, bildirimler, rahatsız etme, sesli arama, profil değiştir.
- **Tuş atama:** (1) Uygulama yönlendirme: kumandanın Netflix gibi sabit tuşu açtığı uygulamayı sen seçtiğin uygulamaya çevirir; tuşları okumaz. (2) Tuş servisi (isteğe bağlı): "Tuşu öğren" ile bir tuşa kısa/uzun basış için uygulama, hızlı panel, sesli arama, ana ekran veya uyku ata. Kod olarak tuş kodu ve tarama kodu kaydedilir (TCL kumandasının ek tuşları için).
- **Sistem ve kurulum ekranı:** servis durumları, Android sürümü (DualSense için 12+), güvenlik yaması yaşı, gizlilik özeti.

## Bu sürümde YOK (sonraki adım)
Boşta ekran (saat/fotoğraf), duvar kağıdı ve vurgu rengi seçimi, kullanım özeti, ayar yedeği, açılışta doğrudan uygulama, misafir profili, ses sınırı, tuşlarda çift basış, kategori klasörleri. Önce bu sürümü TV'de sağlam çalıştıralım.

## Hız notları (ölçülmedi, TCL'de denenecek)
- "Son kullanılanlar" yalnızca 12 paket adı tutar; hız etkisi ihmal edilebilir. "Devam et" sistemden bir sorgu yapar; yalnızca ana ekran kurulurken ve uygulamadan dönünce, listede değişiklik olursa yenilenir.
- Profil sayısı hızı etkilemez (en çok 6 profil; ayarlar küçük bir metin olarak okunur ve önbelleğe alınır).
- Asıl yük kutucuk sayısıdır. Öneri: kategori başına en çok 15 uygulama, toplamda 100 kutucuğun altında kal. Odak dışındaki kutucuklarda gölge ve ekran katmanı kapalı tutulur.

## Arka plandaki uygulamalar
- Uygulamadan çıkınca uygulama kapanmaz; Android onu bellekte (önbellekte) bekletir ve genellikle duraklatır. Bellek azalınca en eskileri kendisi kapatır. Bazı uygulamalar (müzik, indirme, IPTV kayıt ve rehber güncellemesi) arkada iş yapabilir.
- Android 14 ve üstünde üçüncü taraf bir uygulama başka uygulamaların arka planını kapatamaz; 13 ve altında izinle mümkündü ama Google bunu önermiyor (yeniden açılış daha çok kaynak harcar). Bu yüzden toplu "temizle" düğmesi yok.
- Bir uygulamayı elle kapatmak için: ana ekranda uygulamaya uzun bas > **Uygulama bilgisi** > **Zorla durdur**.

## Performans ölçümü
Ayarlar > Sistem ve kurulum > **Performans ölçümü**: açılış süresi, uygulamanın bellek kullanımı (WebView'ın ayrı görüntü işleme süreci hariç), boş sistem belleği ve tuş işleme süresi (JavaScript tarafı). Bu sayıları bana yaz; WebView ana ekranın TCL'de yeterli olup olmadığına buna göre karar veririz.

## Yerel ana ekran (hazırlık, henüz uygulamaya bağlı değil)
`app/src/main/java/com/abert/tv/ui/` klasörü, ana ekranın WebView'sız yerel çizim katmanıdır (Gfx, AndroidGfx, SvgPath, HomeScene). Şu an kullanılmıyor; ekran görüntüleri bilgisayarda aynı çizim koduyla alınıp doğrulandı (`tools/native-preview`). Sonraki adım: veri bağlantısı, kumanda girişi ve açma/kapama anahtarı.

## Güvenlik ve gizlilik
- Uygulamada **INTERNET izni yok**; teknik olarak hiçbir şey gönderemez. Telemetri yok.
- Arayüz yalnızca uygulamanın kendi dosyalarını yükler; dışarıya her istek engellenir.
- Şifre tuzlu ve 10.000 turlu SHA-256 ile saklanır; düz metin tutulmaz.
- "Koruma ve Ana Sayfa" servisi yalnızca "hangi pencere açıldı" bilgisini görür; ekran içeriğini ve tuşları okumaz.
- "Tuş atama" servisi ayrı ve isteğe bağlı: tuşları görebildiği için kapalı tutabilirsin. Atanmamış tuşları işlemeden geçirir, çocuk profilinde ve profil seçiminde devre dışıdır.
- "Bildirim erişimi" isteğe bağlı: tüm uygulamaların bildirimini okuyabilen bir izindir; bu yüzden yalnızca yetişkin profilinde, bellekte ve internetsiz çalışır.
- `QUERY_ALL_PACKAGES` izni var: uygulama listesini ve simgelerini gösterebilmek için.
- Kalan riskler: TV'nin fiziksel sıfırlaması, ADB'nin açık kalması (kurulum bitince kapat), Google TV güncellemelerinin Ana Sayfa devralmayı bozması.
- İmza anahtarı bu depoda (`app/debug.keystore`) ve herkese açık. Depoyu herkese açık yaparsan, güncellemeyi **yalnızca kendi deponun** APK'sından kur.

---

# KURULUM: senin yapacakların

## 1) APK'yı derle (bilgisayarsız, telefondan da yapılır)
Gerekenler: ücretsiz bir GitHub hesabı.
1. github.com'da hesap aç, **New repository** de, adı `abert-tv`, **Public** seç, **Create repository**.
2. Depoda **Add file > Create new file**. Dosya adı kutusuna aynen yaz: `.github/workflows/build.yml`
   Buraya bu paketteki `build.yml` dosyasının içeriğini yapıştır, **Commit changes**.
3. **Add file > Upload files**: bu paketteki **`proje.zip`** dosyasını yükle, **Commit changes**.
   (Zip'i açma, olduğu gibi yükle.)
4. Üstteki **Actions** sekmesinde "APK derle" çalışmaya başlar (5 ila 10 dakika). Yeşil tik olunca bitmiştir. Kırmızıysa içindeki hata satırlarını bana yapıştır.
5. Depo ana sayfasında sağdaki **Releases > latest** içinde `abert-tv.apk` oluşur.
   İndirme bağlantısı: `https://github.com/KULLANICI_ADIN/abert-tv/releases/download/latest/abert-tv.apk`

Bilgisayarda Android Studio ile derlemek istersen: klasörü aç (File > Open), Gradle eşitlenince Build > Build APK(s).

## 2) TV'ye kur
**Bilgisayarsız yol (önerilen):**
1. TV'de Play Store'dan **Downloader** (AFTVnews) uygulamasını kur.
2. TV Ayarları'nda Downloader'a "bilinmeyen kaynaklardan kurulum" izni ver. Yolu TCL'de değişebilir; genelde Ayarlar > Cihaz tercihleri > Güvenlik ve kısıtlamalar > Bilinmeyen kaynaklar. Downloader'ı ilk açıp APK kurmayı denersen sistem seni doğru ekrana götürür.
3. Downloader'ı aç, adres kutusuna yukarıdaki indirme bağlantısını yaz, **Git**, indirilince **Kur**.

**Bilgisayarla yol:** TV'de Ayarlar > Hakkında > Derleme numarasına 7 kez bas, Geliştirici seçenekleri'nden "ağ hata ayıklama"yı aç. Sonra:
```
adb connect TV_IP:5555
adb install -r abert-tv.apk
```

## 3) İlk açılış: servisleri aç (kritik)
1. Uygulamalar listesinden **Abert TV**'yi aç.
2. **Ayarlar > Sistem ve kurulum**'da ilk kutuya OK bas. Açılan erişilebilirlik listesinden **Abert TV Koruma ve Ana Sayfa** servisini aç.
   - TCL'de "bunu yapacak uygulama yok" hatası çıkarsa: TV Ayarları > Sistem (veya Cihaz tercihleri) > Erişilebilirlik > servisi seç.
   - Hâlâ olmazsa bilgisayardan: `adb shell settings put secure enabled_accessibility_services com.abert.tv/com.abert.tv.KidsGuardService` ve `adb shell settings put secure accessibility_enabled 1`
3. Ana Sayfa tuşuna bas: Google TV'nin kendi ekranı açılırsa kısa sürede bu ekrana dönmesi gerekir. Dönmezse: `adb shell cmd package set-home-activity com.abert.tv/.MainActivity`
4. **Projectivy** veya başka bir launcher kullandıysan onun erişilebilirlik iznini kapat (iki servis çakışır).
5. İsteğe bağlı: **Tuş atama** servisi ve **Bildirim erişimi** için aynı ekrandaki kutulara bas. Bildirim erişimi yolu: Ayarlar > Uygulamalar > Özel uygulama erişimi > Bildirim erişimi.

## 4) Profilleri kur
1. **Ayarlar > Şifreyi değiştir**: yetişkin şifreni belirle.
2. **Ayarlar > Profiller > Yeni profil**: ad (klavye veya mikrofon), tür, uygulamalar, yazı boyutu.
3. Çocuk için: tür **Çocuk**, uygulamaları seç, **Ayarlar > Çocuk süre sınırı**.
4. Yaşlı için: tür **Kolay**, 4 ila 6 uygulama seç. Çocuk bu profili seçip kısıtları aşmasın diye "Girişte şifre"yi aç.
5. Birden fazla profil olunca TV her açılışta "Kim izliyor?" sorar.

## 5) Telefonu kumanda ve klavye yap (Google'ın kendi uygulaması)
Bizim launcher bunu bozmaz; Google TV'nin sistem özelliğidir.
1. Telefonda **Google TV** uygulamasını aç, sağ altta **Remote** (Kumanda) de.
2. TV'yi seç, TV'de çıkan kodu telefona gir, **Pair**.
3. Telefon ve TV aynı Wi-Fi'de olmalı. Klavye simgesiyle telefonun klavyesiyle yazabilirsin; klavye her uygulamada çalışmayabilir.
4. Çocuk profilinde bu eşleştirme penceresi koruma tarafından engellenir; eşleştirmeyi yetişkin profilinde yap.

## 6) Test listesi (TV'de bunları dene, sonucu bana yaz)
1. TV'yi uykuya al, uyandır: "Kim izliyor?" geliyor mu? (2+ profil varken)
2. Ana Sayfa tuşu Google ekranı yerine Abert TV'yi açıyor mu?
3. Çocuk profilinde onaysız bir uygulamayı açmayı dene (kumandadan veya Ayarlar'dan): geri atıyor mu?
4. Çocuk profilinde süre sınırını 15 dk yap, bitince kilit ekranı geliyor mu?
5. Kolay profilde büyük yazı ve sade ekran doğru mu? Ayarlar şifre istiyor mu?
6. DualSense'i eşleştir (PS + Create tuşları basılı): gezinme, Çarpı, Daire çalışıyor mu? (TV'nin Android sürümü 12'den eskiyse tam çalışmayabilir.)
7. Sesli arama kutusu Google asistanını açıyor mu, Türkçe anlıyor mu?
8. Profil adı yazarken klavye açılıyor mu, mikrofon düğmesi var mı? Telefondan yazınca gidiyor mu?
9. Bildirim merkezi: Bildirim erişimini aç, bir uygulamadan bildirim gelince listeye düşüyor mu?
10. Tuşu öğren: kumandanın bir ek tuşuna bas, algılıyor mu? (TCL'de bazı tuşlar aynı kodla gelebilir, bunu görmek istiyorum.)
11. Uygulama yönlendirme: Netflix tuşuna basınca seçtiğin uygulama açılıyor mu?
12. 4K bir YouTube videosu ve Play Store'dan bir uygulama indirme normal çalışıyor mu?
13. Launcher'ın açılış ve gezinme hızı: takılma var mı?
14. Kategori: Ayarlar > Ana ekran düzeni > Kategoriler ile bir kategori oluştur, uygulama koy; ana ekranda satır olarak çıkıyor mu? Uygulamaya uzun basınca menü açılıyor mu?
15. Devam et: bir videoyu yarıda bırak (örn. YouTube), ana ekranda 'Devam et' satırında çıkıyor mu? (İlk seferde izin ekranı gelir.)
16. Son kullanılanlar: iki profilde farklı uygulamalar aç, her profilin satırı kendi uygulamalarını gösteriyor mu?
17. Çocuk uyku saati: profilde saati şimdiyi kapsayacak şekilde ayarla, çocuk profili kilitleniyor mu?

## Sorun giderme
- **Ana ekran çok kısa yanıp Google ekranına dönüyor:** Ana Sayfa devralma kapalı olabilir (Ayarlar > Ana Sayfa devralma) veya servis kapalı.
- **Çocuk profiline geçilmiyor:** Koruma servisi kapalıdır; adım 3.
- **TV yavaşladı:** önce **Tuş atama** servisini kapat. Tuş yakalayan servisler bazı TV'lerde gecikme yapabiliyor.
- **Her şeyi geri almak:** TV Ayarları > Uygulamalar > Abert TV > Kaldır. Google TV ekranı geri gelir.
- Bir şey çökerse uygulama kendini yeniden başlatır; ekran açılmazsa bana hatanın ne olduğunu yaz.

## Kod haritası
- `Policy.kt` profiller, şifre, süre, kurallar (cihazda SharedPreferences)
- `KidsGuardService.kt` koruma, Ana Sayfa devralma, yönlendirme, uyku, uyarılar
- `KeyMapService.kt` isteğe bağlı tuş atama
- `NotifService.kt`, `Notices.kt` bildirim merkezi (bellekte)
- `MainActivity.kt` WebView ana ekranı, oyun kolu, `Bridge` (arayüzün çağırabildiği tek yer)
- `assets/index.html` arayüz (yazı tipi gömülü, internet gerekmez)
