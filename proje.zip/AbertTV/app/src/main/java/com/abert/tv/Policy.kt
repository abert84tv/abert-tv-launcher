package com.abert.tv

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ana ekrandaki özel kategori (satır). Yalnızca düzen; erişim izni profilin uygulama listesinden gelir. */
data class Row(val id: String, val name: String, val apps: List<String>, val folder: Boolean = false) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("apps", JSONArray(apps)).put("folder", folder)
}

/** Bir profil. type: adult (yetişkin), kids (çocuk), easy (kolay, yaşlılar için sade). */
data class Profile(
    val id: String,
    val name: String,
    val type: String,
    val apps: Set<String>,          // ERİŞİM: çocuk ve kolay profilde izinli uygulamalar (koruma servisi bunu uygular)
    val textScale: Int,
    val bold: Boolean,
    val hi: Boolean,
    val motion: Int,                // 0 tam, 1 azaltılmış, 2 yok
    val pinReq: Boolean,
    val color: String,
    val rows: List<Row>,            // DÜZEN: özel kategoriler
    val allRow: Boolean,            // "Tüm uygulamalar" satırı
    val recents: Boolean,           // "Son kullanılanlar" satırı
    val cont: Boolean,              // "Devam et" satırı
    val tileSize: Int,              // 0 küçük (6), 1 orta (5), 2 büyük (4), 3 çok büyük (3)
    val hero: Boolean,
    val labels: Int,                // 0 her zaman, 1 odakta, 2 kapalı
    val glass: Int,                 // menü şeffaflığı 0 kapalı .. 3 yüksek
    val hidden: Set<String>,        // bu profilde ana ekrandan gizlenen uygulamalar
    val bedFrom: Int,               // çocuk uyku saati başlangıcı (dk), -1 kapalı
    val bedTo: Int,
    val menuStyle: Int,             // ayar menüsü stili: 0 Android TV, 1 Apple TV
    val theme: Int,                 // 0 koyu, 1 açık, 2 otomatik (gündüz açık, gece koyu)
    val pins: Set<String>           // klasörlerin yanında tek uygulama olarak sabitlenenler
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("type", type)
        .put("apps", JSONArray(apps.toList())).put("textScale", textScale).put("bold", bold)
        .put("hi", hi).put("motion", motion).put("pinReq", pinReq).put("color", color)
        .put("rows", JSONArray().also { a -> rows.forEach { a.put(it.toJson()) } })
        .put("allRow", allRow).put("recents", recents).put("cont", cont).put("tileSize", tileSize)
        .put("hero", hero).put("labels", labels).put("glass", glass)
        .put("hidden", JSONArray(hidden.toList())).put("bedFrom", bedFrom).put("bedTo", bedTo).put("menuStyle", menuStyle).put("theme", theme).put("pins", JSONArray(pins.toList()))

    companion object {
        val TYPES = setOf("adult", "kids", "easy")
        const val MAX = 6
        const val MAX_ROWS = 12

        fun default(id: String, name: String, type: String): Profile = from(
            JSONObject().put("id", id).put("name", name).put("type", type)
        )!!

        private fun strList(a: JSONArray?, max: Int): List<String> {
            val out = ArrayList<String>()
            if (a != null) for (i in 0 until minOf(a.length(), max)) {
                val v = a.optString(i).take(150)
                if (v.isNotEmpty() && v !in out) out.add(v)
            }
            return out
        }

        fun from(o: JSONObject): Profile? {
            val type = o.optString("type")
            if (type !in TYPES) return null
            val name = o.optString("name").trim().take(16)
            if (name.isEmpty()) return null
            val id = o.optString("id").filter { it.isLetterOrDigit() || it == '_' }.take(24)
            if (id.isEmpty()) return null
            val easy = type == "easy"; val kids = type == "kids"
            val color = o.optString("color").let { if (Regex("^#[0-9A-Fa-f]{6}$").matches(it)) it else "#1F8F7A" }
            val rows = ArrayList<Row>()
            val ra = o.optJSONArray("rows")
            if (ra != null) for (i in 0 until minOf(ra.length(), MAX_ROWS)) {
                val r = ra.optJSONObject(i) ?: continue
                val rn = r.optString("name").trim().take(20)
                val rid = r.optString("id").filter { it.isLetterOrDigit() || it == '_' }.take(24)
                if (rn.isEmpty() || rid.isEmpty() || rows.any { it.id == rid }) continue
                rows.add(Row(rid, rn, strList(r.optJSONArray("apps"), 60), r.optBoolean("folder")))
            }
            fun minute(k: String): Int { val v = o.optInt(k, -1); return if (v in 0..1439) v else -1 }
            var bf = minute("bedFrom"); var bt = minute("bedTo")
            if (bf < 0 || bt < 0 || bf == bt) { bf = -1; bt = -1 }
            return Profile(
                id, name, type, LinkedHashSet(strList(o.optJSONArray("apps"), 200)),
                o.optInt("textScale", if (easy) 150 else 100).coerceIn(100, 175),
                o.optBoolean("bold", easy), o.optBoolean("hi", easy),
                o.optInt("motion", if (easy) 1 else 0).coerceIn(0, 2),
                o.optBoolean("pinReq"), color, rows,
                o.optBoolean("allRow", true), o.optBoolean("recents", type == "adult"), o.optBoolean("cont", type == "adult"),
                o.optInt("tileSize", if (easy) 3 else 1).coerceIn(0, 3),
                o.optBoolean("hero", !easy), o.optInt("labels", if (type == "adult") 1 else 0).coerceIn(0, 2),
                o.optInt("glass", if (easy) 0 else 2).coerceIn(0, 3),
                LinkedHashSet(strList(o.optJSONArray("hidden"), 200)), bf, bt,
                o.optInt("menuStyle", 1).coerceIn(0, 1), o.optInt("theme", 0).coerceIn(0, 2),
                LinkedHashSet(strList(o.optJSONArray("pins"), 24))
            )
        }
    }
}

/** Tüm kural ve durum burada, cihazın kendi deposunda. Hiçbir şey cihaz dışına çıkmaz. */
object Policy {
    private const val SALT_ITER = 10000
    val STOCK_SETTINGS = setOf("com.android.tv.settings", "com.android.settings")

    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("abert", Context.MODE_PRIVATE)
    private fun now() = System.currentTimeMillis()

    // ---------- profiller ----------
    private var pRaw: String? = null
    private var pList: List<Profile> = emptyList()

    /** Profil listesi; ham metin değişmediyse yeniden ayrıştırılmaz (koruma servisi ve arayüz sık çağırır). */
    @Synchronized
    fun profiles(c: Context): List<Profile> {
        val raw = sp(c).getString("profiles", "[]") ?: "[]"
        if (raw == pRaw) return pList
        val out = ArrayList<Profile>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) Profile.from(a.getJSONObject(i))?.let { out.add(it) }
        } catch (_: Throwable) {
        }
        if (out.none { it.type == "adult" }) {
            out.add(0, Profile.default("p1", "Abert", "adult"))
        }
        pRaw = raw
        pList = out
        return out
    }

    fun saveProfiles(c: Context, l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp(c).edit().putString("profiles", a.toString()).apply()
    }

    fun multi(c: Context) = profiles(c).size > 1
    fun activeId(c: Context): String = sp(c).getString("active", null) ?: profiles(c).first().id
    fun setActive(c: Context, id: String) { sp(c).edit().putString("active", id).apply() }

    fun current(c: Context): Profile? {
        val id = activeId(c)
        if (id == "picker") return null
        val l = profiles(c)
        return l.firstOrNull { it.id == id } ?: l.first()
    }

    /** adult | kids | easy | picker */
    fun mode(c: Context): String = if (activeId(c) == "picker") "picker" else (current(c)?.type ?: "adult")

    // ---------- şifre ----------
    private fun hash(pin: String, salt: String): String {
        var d = (salt + pin).toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        repeat(SALT_ITER) { d = md.digest(d) }
        return d.joinToString("") { "%02x".format(it) }
    }

    fun hasPin(c: Context) = sp(c).getString("pinHash", null) != null

    fun setPin(c: Context, pin: String) {
        okMemo = null
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        val salt = b.joinToString("") { "%02x".format(it) }
        sp(c).edit().putString("pinSalt", salt).putString("pinHash", hash(pin, salt))
            .putInt("fails", 0).putLong("lockUntil", 0).apply()
    }

    fun lockLeftSec(c: Context): Int = ((sp(c).getLong("lockUntil", 0) - now()) / 1000).toInt().coerceAtLeast(0)

    /** 0 = doğru, -1 = yanlış, pozitif = kilitli (saniye). */
    @Volatile private var okMemo: String? = null
    @Volatile private var okUntil = 0L
    private fun quick(pin: String): String = MessageDigest.getInstance("SHA-256").digest(("m:" + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun checkPin(c: Context, pin: String): Int {
        val left = lockLeftSec(c)
        if (left > 0) return left
        val h = sp(c).getString("pinHash", null) ?: return -1
        val salt = sp(c).getString("pinSalt", "") ?: ""
        // Aynı şifre az önce doğrulandıysa ağır özet hesabı tekrarlanmaz (arayüzdeki duraklamayı önler)
        if (pin.length == 4 && okMemo != null && System.currentTimeMillis() < okUntil && MessageDigest.isEqual(okMemo!!.toByteArray(), quick(pin + salt).toByteArray())) return 0
        if (pin.length == 4 && MessageDigest.isEqual(hash(pin, salt).toByteArray(), h.toByteArray())) {
            sp(c).edit().putInt("fails", 0).apply()
            okMemo = quick(pin + salt); okUntil = System.currentTimeMillis() + 8000
            return 0
        }
        val f = sp(c).getInt("fails", 0) + 1
        val e = sp(c).edit().putInt("fails", f)
        if (f % 5 == 0) {
            val secs = minOf(900, 60 shl minOf(4, f / 5 - 1))
            e.putLong("lockUntil", now() + secs * 1000L)
        }
        e.apply()
        return -1
    }

    // ---------- kurtarma sorusu: şifre unutulursa yeni şifre belirlemek için (cevabın yalnızca özeti saklanır) ----------
    fun hasRecovery(c: Context) = sp(c).getString("recAHash", null) != null
    fun recoveryQuestion(c: Context): String = sp(c).getString("recQ", "") ?: ""

    /** Cevap yazım farklarından (büyük/küçük harf, boşluk, Türkçe harf) etkilenmesin. */
    private fun normAnswer(s: String): String {
        val t = s.lowercase(java.util.Locale("tr")).trim()
        val sb = StringBuilder()
        for (ch in t) when (ch) {
            'ç' -> sb.append('c'); 'ş' -> sb.append('s'); 'ğ' -> sb.append('g'); 'ü' -> sb.append('u'); 'ö' -> sb.append('o'); 'ı' -> sb.append('i')
            else -> if (ch.isLetterOrDigit()) sb.append(ch)
        }
        return sb.toString()
    }

    fun setRecovery(c: Context, q: String, answer: String): Boolean {
        val n = normAnswer(answer)
        if (q.trim().length < 3 || n.length < 4) return false
        val r = SecureRandom(); val b = ByteArray(16); r.nextBytes(b)
        val salt = b.joinToString("") { "%02x".format(it) }
        sp(c).edit().putString("recQ", q.trim().take(80)).putString("recASalt", salt).putString("recAHash", hash(n, salt))
            .putInt("recAFails", 0).putLong("recALock", 0).apply()
        return true
    }

    /** 0 doğru, -1 yanlış, >0 kilit süresi (sn). Cevap tahmin edilebilir olabileceği için bekleme süreleri uzun: 15 dk, 1 sa, 6 sa, 24 sa. */
    fun checkRecovery(c: Context, answer: String): Int {
        val left = ((sp(c).getLong("recALock", 0) - now()) / 1000).toInt()
        if (left > 0) return left
        val h = sp(c).getString("recAHash", null) ?: return -1
        val salt = sp(c).getString("recASalt", "") ?: ""
        if (MessageDigest.isEqual(hash(normAnswer(answer), salt).toByteArray(), h.toByteArray())) {
            sp(c).edit().putInt("recAFails", 0).apply()
            return 0
        }
        val f = sp(c).getInt("recAFails", 0) + 1
        val e = sp(c).edit().putInt("recAFails", f)
        if (f % 5 == 0) {
            val steps = longArrayOf(900, 3600, 21600, 86400)
            e.putLong("recALock", now() + steps[minOf(steps.size - 1, f / 5 - 1)] * 1000L)
        }
        e.apply()
        return -1
    }

    // ---------- çocuk süre sınırı ----------
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun roll(c: Context) {
        if (sp(c).getString("day", "") != today()) {
            sp(c).edit().putString("day", today()).putLong("used", 0).putInt("bonus", 0)
                .putString("warn10", "").putString("warn1", "").apply()
        }
    }

    fun limitOn(c: Context) = sp(c).getBoolean("limOn", false)
    fun limitMin(c: Context) = sp(c).getInt("limMin", 60)
    fun setLimit(c: Context, on: Boolean, min: Int) {
        sp(c).edit().putBoolean("limOn", on).putInt("limMin", min.coerceIn(15, 300)).apply()
    }
    fun usedSec(c: Context): Long { roll(c); return sp(c).getLong("used", 0) }
    fun addUsed(c: Context, s: Long) { roll(c); sp(c).edit().putLong("used", sp(c).getLong("used", 0) + s).apply() }
    fun addBonus(c: Context) { roll(c); sp(c).edit().putInt("bonus", sp(c).getInt("bonus", 0) + 15).apply() }
    fun resetToday(c: Context) { sp(c).edit().putLong("used", 0).putInt("bonus", 0).putString("warn10", "").putString("warn1", "").apply() }
    fun leftSec(c: Context): Long { roll(c); return (limitMin(c) + sp(c).getInt("bonus", 0)) * 60L - sp(c).getLong("used", 0) }
    fun timeUp(c: Context) = limitOn(c) && leftSec(c) <= 0
    fun warned(c: Context, k: String) = sp(c).getString(k, "") == today()
    fun markWarned(c: Context, k: String) { sp(c).edit().putString(k, today()).apply() }

    // ---------- ana sayfa devralma ve yönlendirme ----------
    fun homeOverride(c: Context) = sp(c).getBoolean("homeOv", true)
    fun setHomeOverride(c: Context, on: Boolean) { sp(c).edit().putBoolean("homeOv", on).apply() }
    fun bypassUntil(c: Context) = sp(c).getLong("bypass", 0)
    fun markBypass(c: Context, ms: Long) { sp(c).edit().putLong("bypass", now() + ms).apply() }
    fun markLaunch(c: Context) { sp(c).edit().putLong("lastLaunch", now()).apply() }
    fun recentLaunch(c: Context, ms: Long) = now() - sp(c).getLong("lastLaunch", 0) < ms
    fun hidden(c: Context): Set<String> = strSet(c, "hidden")
    fun setHidden(c: Context, s: Set<String>) = putSet(c, "hidden", s)

    fun redirects(c: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        try {
            val a = JSONArray(sp(c).getString("redirects", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val f = o.optString("from"); val t = o.optString("to")
                if (f.isNotEmpty() && t.isNotEmpty() && f != t) m[f] = t
            }
        } catch (_: Throwable) {
        }
        return m
    }
    fun setRedirects(c: Context, m: Map<String, String>) {
        val a = JSONArray()
        m.forEach { (f, t) -> a.put(JSONObject().put("from", f).put("to", t)) }
        sp(c).edit().putString("redirects", a.toString()).apply()
    }
    fun lastForeign(c: Context): String = sp(c).getString("lastForeign", "") ?: ""
    fun setLastForeign(c: Context, p: String) { sp(c).edit().putString("lastForeign", p).apply() }

    // ---------- tuş atama ----------
    fun keyMapOn(c: Context) = sp(c).getBoolean("keyOn", false)
    fun setKeyMapOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("keyOn", on).apply() }
    fun keymapJson(c: Context): String = sp(c).getString("keymap", "[]") ?: "[]"
    fun setKeymapJson(c: Context, s: String) { sp(c).edit().putString("keymap", s).apply() }
    fun learning(c: Context) = sp(c).getLong("learnUntil", 0) > now()
    fun learnStart(c: Context) { sp(c).edit().putLong("learnUntil", now() + 30000).putString("lastKey", "").apply() }
    fun learnStop(c: Context) { sp(c).edit().putLong("learnUntil", 0).apply() }
    fun lastKey(c: Context): String = sp(c).getString("lastKey", "") ?: ""
    fun setLastKey(c: Context, s: String) { sp(c).edit().putString("lastKey", s).apply() }

    // ---------- bildirim ayarları ----------
    fun dnd(c: Context) = sp(c).getBoolean("dnd", false)
    fun setDnd(c: Context, on: Boolean) { sp(c).edit().putBoolean("dnd", on).apply() }
    fun notifContent(c: Context) = sp(c).getBoolean("notifContent", false)
    fun setNotifContent(c: Context, on: Boolean) { sp(c).edit().putBoolean("notifContent", on).apply() }
    fun notifDenied(c: Context): Set<String> = strSet(c, "notifDenied")
    fun setNotifDenied(c: Context, s: Set<String>) = putSet(c, "notifDenied", s)

    // ---------- uyku zamanlayıcı ----------
    fun sleepAt(c: Context) = sp(c).getLong("sleepAt", 0)
    fun setSleepAt(c: Context, t: Long) { sp(c).edit().putLong("sleepAt", t).apply() }

    // ---------- son kullanılanlar (profil başına, yalnızca cihazda) ----------
    fun recents(c: Context, id: String): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp(c).getString("recent_$id", "[]"))
            for (i in 0 until a.length()) out.add(a.optString(i))
        } catch (_: Throwable) {
        }
        return out
    }
    fun addRecent(c: Context, id: String, pkg: String) {
        val l = ArrayList(recents(c, id))
        l.remove(pkg); l.add(0, pkg)
        while (l.size > 12) l.removeAt(l.size - 1)
        sp(c).edit().putString("recent_$id", JSONArray(l).toString()).apply()
    }
    fun clearRecents(c: Context, id: String) { sp(c).edit().remove("recent_$id").apply() }

    // ---------- çocuk uyku saati ----------
    fun bedtime(c: Context): Boolean {
        val p = current(c) ?: return false
        if (p.type != "kids" || p.bedFrom < 0 || p.bedTo < 0) return false
        val cal = Calendar.getInstance()
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (p.bedFrom < p.bedTo) m in p.bedFrom until p.bedTo else (m >= p.bedFrom || m < p.bedTo)
    }

    // ---------- şifre girişi, duvar kağıdı, ekran koruyucu (genel ayarlar) ----------
    /** 0 tuş takımı, 1 yön tuşlarıyla rakam seçme (Google tarzı). Varsayılan 1. */
    fun pinStyle(c: Context): Int = sp(c).getInt("pinStyle", 1)
    fun setPinStyle(c: Context, v: Int) { sp(c).edit().putInt("pinStyle", v.coerceIn(0, 1)).apply() }
    /** Kumanda halkalı şifrede sağdaki rakam listesi görünsün mü (kullanıcının son tercihi kalır). */
    fun pinRows(c: Context): Boolean = sp(c).getBoolean("pinRows", true)
    fun setPinRows(c: Context, v: Boolean) { sp(c).edit().putBoolean("pinRows", v).apply() }

    /** 0 otomatik, 1 Google Asistan, 2 Arama tuşu (kumandadaki mikrofon gibi), 3 sesle ara, 4 Google uygulaması */
    fun voiceMethod(c: Context): Int = sp(c).getInt("voiceM", 0)
    fun setVoiceMethod(c: Context, v: Int) { sp(c).edit().putInt("voiceM", v.coerceIn(0, 3)).apply() }

    /** Hızlı panel düzeni: sıra ve açık/kapalı (genel ayar). Boşsa varsayılan düzen kullanılır. */
    fun quickJson(c: Context): String = sp(c).getString("quick", "") ?: ""
    fun setQuickJson(c: Context, s: String) { sp(c).edit().putString("quick", s).apply() }

    /** "" yok, "image", "gif", "video". Dosya uygulamanın kendi klasöründe: wall.<ext> */
    fun wall(c: Context): String = sp(c).getString("wall", "") ?: ""
    fun wallExt(c: Context): String = sp(c).getString("wallExt", "") ?: ""
    fun setWall(c: Context, kind: String, ext: String) { sp(c).edit().putString("wall", kind).putString("wallExt", ext).apply() }
    fun wallDim(c: Context): Int = sp(c).getInt("wallDim", 1)
    fun setWallDim(c: Context, v: Int) { sp(c).edit().putInt("wallDim", v.coerceIn(0, 3)).apply() }

    /** Kullanıcının seçtiği ekran koruyucu; sistem başka bir şeye döndürürse yeniden yazılır. */
    fun dreamWanted(c: Context): String = sp(c).getString("dream", "") ?: ""
    fun setDreamWanted(c: Context, comp: String) { sp(c).edit().putString("dream", comp).apply() }
    fun dreamOrig(c: Context): String = sp(c).getString("dreamOrig", "") ?: ""
    fun setDreamOrig(c: Context, v: String) { sp(c).edit().putString("dreamOrig", v).apply() }
    fun canWriteSecure(c: Context): Boolean =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
    fun reapplyDream(c: Context) {
        val want = dreamWanted(c)
        if (want.isEmpty() || !canWriteSecure(c)) return
        try {
            val cr = c.contentResolver
            if ((Settings.Secure.getString(cr, "screensaver_components") ?: "") != want) {
                Settings.Secure.putString(cr, "screensaver_components", want)
                Settings.Secure.putInt(cr, "screensaver_enabled", 1)
            }
        } catch (_: Throwable) {
        }
    }

    // ---------- yedekleme: yalnızca ayarlar; şifre, kurtarma kodu ve geçici durumlar yedeğe girmez ----------
    private val BK_BOOL = listOf("limOn", "homeOv", "keyOn", "dnd", "notifContent", "pinRows")
    private val BK_INT = listOf("limMin", "pinStyle", "wallDim")
    private val BK_STR = listOf("keymap", "redirects", "quick", "dream")

    fun exportJson(c: Context): String {
        val s = sp(c)
        val set = JSONObject()
        for (k in BK_BOOL) if (s.contains(k)) set.put(k, s.getBoolean(k, false))
        for (k in BK_INT) if (s.contains(k)) set.put(k, s.getInt(k, 0))
        for (k in BK_STR) if (s.contains(k)) set.put(k, s.getString(k, "") ?: "")
        val profs = JSONArray(); for (pr in profiles(c)) profs.put(pr.toJson())
        return JSONObject().put("app", "abert-tv").put("v", 1).put("t", now()).put("profiles", profs).put("settings", set).toString()
    }

    /** Geçersiz veya yetişkin profili olmayan yedek reddedilir; şifre ve kurtarma kodu değişmez. */
    fun importJson(c: Context, json: String): Boolean {
        val o = try { JSONObject(json) } catch (_: Throwable) { return false }
        if (o.optString("app") != "abert-tv") return false
        val arr = o.optJSONArray("profiles") ?: return false
        val list = ArrayList<Profile>()
        for (i in 0 until minOf(arr.length(), Profile.MAX)) { val pr = arr.optJSONObject(i)?.let { Profile.from(it) } ?: continue; if (list.none { it.id == pr.id }) list.add(pr) }
        if (list.none { it.type == "adult" }) return false
        val set = o.optJSONObject("settings") ?: JSONObject()
        val e = sp(c).edit()
        e.putString("profiles", JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString())
        for (k in BK_BOOL) if (set.has(k)) e.putBoolean(k, set.optBoolean(k))
        for (k in BK_INT) if (set.has(k)) e.putInt(k, set.optInt(k))
        for (k in BK_STR) if (set.has(k)) e.putString(k, set.optString(k).take(20000))
        e.putString("active", if (list.size > 1) "picker" else list.first { it.type == "adult" }.id)
        e.apply()
        return true
    }

    // ---------- sıfırlama ve çökme izleme ----------
    /** Her şeyi varsayılana döndürür; şifre korunur. */
    fun resetAll(c: Context) {
        val s = sp(c)
        val h = s.getString("pinHash", null); val salt = s.getString("pinSalt", null)
        val rq = s.getString("recQ", null); val rh = s.getString("recAHash", null); val rs = s.getString("recASalt", null)
        s.edit().clear().apply()
        if (h != null) s.edit().putString("pinHash", h).putString("pinSalt", salt).apply()
        if (rh != null) s.edit().putString("recQ", rq).putString("recAHash", rh).putString("recASalt", rs).apply()
    }
    fun noteCrash(c: Context) {
        val l = ArrayList<Long>()
        try {
            val a = JSONArray(sp(c).getString("crashes", "[]"))
            for (i in 0 until a.length()) l.add(a.optLong(i))
        } catch (_: Throwable) {
        }
        l.add(now())
        while (l.size > 3) l.removeAt(0)
        sp(c).edit().putString("crashes", JSONArray(l).toString()).commit()
    }
    /** Son 2 dakikada 2 çökme varsa true. */
    fun crashLoop(c: Context): Boolean {
        var n = 0
        try {
            val a = JSONArray(sp(c).getString("crashes", "[]"))
            for (i in 0 until a.length()) if (now() - a.optLong(i) < 120000) n++
        } catch (_: Throwable) {
        }
        return n >= 2
    }
    fun clearCrashes(c: Context) { sp(c).edit().remove("crashes").apply() }

    // ---------- yardımcılar ----------
    private fun strSet(c: Context, k: String): Set<String> {
        val s = HashSet<String>()
        try {
            val a = JSONArray(sp(c).getString(k, "[]"))
            for (i in 0 until a.length()) s.add(a.optString(i))
        } catch (_: Throwable) {
        }
        return s
    }
    private fun putSet(c: Context, k: String, s: Set<String>) {
        sp(c).edit().putString(k, JSONArray(s.toList()).toString()).apply()
    }
    fun flag(c: Context, k: String) = sp(c).getBoolean(k, false)
    fun setFlag(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun prefs(c: Context) = sp(c)
}
