package com.abert.tv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.tv.TvContract
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.ceil

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var lastDir = 0
    private var lastDirT = 0L

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Güvenli mod: kısa sürede üst üste çökerse Ana Sayfa devralmayı kapat ve Google ana ekranına dön.
        if (Policy.crashLoop(this)) {
            Policy.clearCrashes(this)
            Policy.setHomeOverride(this, false)
            Policy.markBypass(this, 10 * 60000L)
            Toast.makeText(this, "Abert TV güvenli moda geçti: Google ana ekranı açılıyor", Toast.LENGTH_LONG).show()
            packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                .firstOrNull { it.activityInfo.packageName != packageName }?.let {
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        .setClassName(it.activityInfo.packageName, it.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            finish()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({ Policy.clearCrashes(this) }, 30000)
        web = WebView(this)
        web.setBackgroundColor(0xFF080B12.toInt())
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        WebView.setWebContentsDebuggingEnabled(false)
        // Arayüz yalnızca uygulamanın kendi dosyalarını yükleyebilir; dışarıya her istek engellenir.
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                request == null || !isLocal(request.url)

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                if (request != null && !isLocal(request.url))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(this), "Native")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        web.requestFocus()
    }

    private fun isLocal(u: Uri): Boolean =
        (u.scheme == "file" && (u.path ?: "").startsWith("/android_asset/")) ||
            u.scheme == "data" || u.scheme == "about"

    override fun onResume() {
        super.onResume()
        immersive()
        js("window.onHome&&window.onHome()")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        val open = intent?.getStringExtra("open")
        if (open == "quick") js("window.onOpen&&window.onOpen('quick')")
        else js("window.onHome&&window.onHome()")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    /** Geri tuşu launcher'dan asla çıkmaz, sadece arayüze iletilir. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            js("window.onBack&&window.onBack()")
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Oyun kolu (DualSense, Xbox vb.) ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val s = e.source
        val pad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (pad) {
            val mapped = when (e.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER   // Çarpı = seç
                KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK          // Daire = geri
                else -> 0
            }
            if (mapped != 0) {
                return super.dispatchKeyEvent(
                    KeyEvent(e.downTime, e.eventTime, e.action, mapped, e.repeatCount, e.metaState, e.deviceId, 0, e.flags, InputDevice.SOURCE_KEYBOARD)
                )
            }
            val name = when (e.keyCode) {
                KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_START -> "quick"
                KeyEvent.KEYCODE_BUTTON_Y -> "voice"
                KeyEvent.KEYCODE_BUTTON_L1 -> "prev"
                KeyEvent.KEYCODE_BUTTON_R1 -> "next"
                else -> null
            }
            if (name != null) {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) js("window.padKey&&window.padKey('$name')")
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(ev: MotionEvent): Boolean {
        if ((ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && ev.action == MotionEvent.ACTION_MOVE) {
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val x = ev.getAxisValue(MotionEvent.AXIS_X)
            val y = ev.getAxisValue(MotionEvent.AXIS_Y)
            val dx = if (abs(hx) > 0.5f) hx else if (abs(x) > 0.6f) x else 0f
            val dy = if (abs(hy) > 0.5f) hy else if (abs(y) > 0.6f) y else 0f
            val code = when {
                dx == 0f && dy == 0f -> 0
                abs(dx) >= abs(dy) -> if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                else -> if (dy > 0) KeyEvent.KEYCODE_DPAD_DOWN else KeyEvent.KEYCODE_DPAD_UP
            }
            if (code == 0) { lastDir = 0; return true }
            val now = SystemClock.uptimeMillis()
            if (code != lastDir || now - lastDirT > 170) {
                lastDir = code
                lastDirT = now
                dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0))
                dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0))
            }
            return true
        }
        return super.onGenericMotionEvent(ev)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        js("window.onHome&&window.onHome()")
    }

    fun showIme() {
        runOnUiThread {
            try {
                web.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(web, InputMethodManager.SHOW_FORCED)
            } catch (_: Throwable) {
            }
        }
    }

    private fun js(s: String) { web.post { web.evaluateJavascript(s, null) } }
}

/** Web arayüzünün çağırabildiği tek yer. Her değişiklik burada yetki kontrolünden geçer. */
class Bridge(private val a: MainActivity) {
    private val artCache = HashMap<String, String>()

    private fun mode() = Policy.mode(a)
    private fun auth(pin: String): Boolean = mode() == "adult" || Policy.checkPin(a, pin) == 0
    private fun adultOnly(): Boolean = mode() == "adult"

    // ---------- uygulamalar ----------
    @JavascriptInterface
    fun apps(): String {
        val pm = a.packageManager
        val seen = HashSet<String>()
        val arr = JSONArray()
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        for (i in intents) for (ri in pm.queryIntentActivities(i, 0)) {
            val p = ri.activityInfo.packageName
            if (p == a.packageName || !seen.add(p)) continue
            arr.put(JSONObject().put("id", p).put("n", ri.loadLabel(pm).toString()))
        }
        return arr.toString()
    }

    private fun toBitmap(d: Drawable, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, w, h)
        d.draw(c)
        return b
    }

    /** Uygulamanın kendi resmi banner'ı (yoksa ikonu), cihazdaki gerçek dosyadan. */
    @JavascriptInterface
    fun icon(pkg: String): String {
        artCache[pkg]?.let { return it }
        val pm = a.packageManager
        var type = "banner"
        var dr: Drawable? = null
        try { pm.getLeanbackLaunchIntentForPackage(pkg)?.let { dr = pm.getActivityBanner(it) } } catch (_: Throwable) { }
        if (dr == null) try { dr = pm.getApplicationBanner(pkg) } catch (_: Throwable) { }
        if (dr == null) {
            type = "icon"
            try { dr = pm.getApplicationIcon(pkg) } catch (_: Throwable) { }
        }
        val d = dr ?: return ""
        return try {
            val w = if (type == "banner") 320 else 192
            val h = if (type == "banner") 180 else 192
            val bos = ByteArrayOutputStream()
            toBitmap(d, w, h).compress(Bitmap.CompressFormat.PNG, 100, bos)
            val s = JSONObject().put("t", type)
                .put("d", "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).toString()
            artCache[pkg] = s
            s
        } catch (_: Throwable) { "" }
    }

    @JavascriptInterface
    fun launch(pkg: String): Boolean {
        val m = mode()
        if (m == "picker" || pkg == a.packageName) return false
        val p = Policy.current(a)
        if (m == "kids" && (Policy.timeUp(a) || Policy.bedtime(a) || p == null || pkg !in p.apps)) return false
        if (m == "easy" && (p == null || pkg !in p.apps)) return false
        val i = Util.launchIntent(a, pkg) ?: return false
        Policy.markLaunch(a)
        if (p != null && p.recents) Policy.addRecent(a, p.id, pkg)
        a.runOnUiThread { try { a.startActivity(i) } catch (_: Throwable) { } }
        return true
    }

    // ---------- Devam et (sistemin "sıradaki" listesi), profile göre süzülür ----------
    private class Cont(val id: Long, val title: String, val pkg: String, val t: Long, val pct: Int, val intent: String)
    private val contMap = HashMap<Long, Cont>()
    private val PERM = "android.permission.READ_TV_LISTINGS"

    @JavascriptInterface
    fun contPerm(): Boolean = a.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    @JavascriptInterface
    fun contRequest(): Boolean {
        if (contPerm()) return true
        a.runOnUiThread { try { a.requestPermissions(arrayOf(PERM), 7) } catch (_: Throwable) { } }
        return false
    }

    /** Sistemin "Devam et" kayıtları cihaz geneli tek listedir; burada yalnızca bu profilin görebildiği uygulamalara göre süzülür. */
    @JavascriptInterface
    fun cont(): String {
        val out = JSONArray()
        contMap.clear()
        val p = Policy.current(a)
        if (mode() == "picker" || p == null || !p.cont || !contPerm()) return out.toString()
        val items = ArrayList<Cont>()
        try {
            a.contentResolver.query(TvContract.WatchNextPrograms.CONTENT_URI, null, null, null, null)?.use { c ->
                val iId = c.getColumnIndex("_id"); val iT = c.getColumnIndex("title"); val iP = c.getColumnIndex("package_name")
                val iU = c.getColumnIndex("intent_uri"); val iL = c.getColumnIndex("last_engagement_time_utc_millis")
                val iD = c.getColumnIndex("duration_millis"); val iPos = c.getColumnIndex("last_playback_position_millis")
                while (c.moveToNext() && items.size < 60) {
                    val pkg = if (iP >= 0) c.getString(iP) ?: "" else ""
                    if (pkg.isEmpty() || pkg == a.packageName) continue
                    if (p.type != "adult" && pkg !in p.apps) continue
                    if (pkg in p.hidden) continue
                    val dur = if (iD >= 0) c.getLong(iD) else 0L
                    val pos = if (iPos >= 0) c.getLong(iPos) else 0L
                    val pct = if (dur > 0) ((pos * 100) / dur).toInt().coerceIn(0, 100) else 0
                    items.add(Cont(
                        if (iId >= 0) c.getLong(iId) else items.size.toLong(),
                        (if (iT >= 0) c.getString(iT) else null) ?: "", pkg,
                        if (iL >= 0) c.getLong(iL) else 0L, pct,
                        (if (iU >= 0) c.getString(iU) else null) ?: ""
                    ))
                }
            }
        } catch (_: Throwable) { }
        items.sortByDescending { it.t }
        val pm = a.packageManager
        for (it in items.take(12)) {
            contMap[it.id] = it
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(it.pkg, 0)).toString() } catch (_: Throwable) { it.pkg }
            out.put(JSONObject().put("id", it.id).put("title", it.title.take(80)).put("app", label).put("pkg", it.pkg).put("pct", it.pct))
        }
        return out.toString()
    }

    /** Kaydı açar; niyet yalnızca kaydı yayınlayan uygulamaya gidiyorsa kullanılır, aksi halde uygulama doğrudan açılır. */
    @JavascriptInterface
    fun contOpen(id: Long): Boolean {
        val c = contMap[id] ?: return false
        val m = mode()
        if (m == "picker") return false
        val p = Policy.current(a)
        if (m == "kids" && (Policy.timeUp(a) || Policy.bedtime(a))) return false
        if (m != "adult" && (p == null || c.pkg !in p.apps)) return false
        var i: Intent? = null
        try {
            val parsed = Intent.parseUri(c.intent, Intent.URI_INTENT_SCHEME)
            parsed.selector = null
            parsed.flags = Intent.FLAG_ACTIVITY_NEW_TASK        // izin devreden bayrakları at
            val target = parsed.component?.packageName ?: parsed.`package` ?: parsed.resolveActivity(a.packageManager)?.packageName
            if (target == c.pkg && parsed.resolveActivity(a.packageManager) != null) i = parsed
        } catch (_: Throwable) { }
        val go = i ?: Util.launchIntent(a, c.pkg) ?: return false
        Policy.markLaunch(a)
        if (p != null && p.recents) Policy.addRecent(a, p.id, c.pkg)
        a.runOnUiThread { try { a.startActivity(go) } catch (_: Throwable) { } }
        return true
    }

    @JavascriptInterface
    fun clearRecents(id: String, pin: String): Boolean { if (!auth(pin)) return false; Policy.clearRecents(a, id); return true }

    @JavascriptInterface
    fun resetAll(pin: String): Boolean { if (!auth(pin)) return false; Policy.resetAll(a); return true }

    // ---------- durum ----------
    @JavascriptInterface
    fun state(): String {
        val ps = Policy.profiles(a)
        val pa = JSONArray()
        ps.forEach { pa.put(it.toJson()) }
        val left = Policy.leftSec(a)
        val red = JSONArray()
        Policy.redirects(a).forEach { (f, t) -> red.put(JSONObject().put("from", f).put("to", t)) }
        return JSONObject()
            .put("profiles", pa)
            .put("active", Policy.activeId(a))
            .put("mode", mode())
            .put("hasPin", Policy.hasPin(a))
            .put("lockLeft", Policy.lockLeftSec(a))
            .put("limit", JSONObject().put("on", Policy.limitOn(a)).put("min", Policy.limitMin(a))
                .put("used", Policy.usedSec(a) / 60).put("left", ceil(left / 60.0).toInt()).put("up", Policy.timeUp(a)))
            .put("homeOv", Policy.homeOverride(a))
            .put("guardOn", KidsGuardService.enabled(a))
            .put("keyOn", KeyMapService.enabled(a))
            .put("notifOn", Util.notifAccessEnabled(a))
            .put("keyMapOn", Policy.keyMapOn(a))
            .put("dnd", Policy.dnd(a))
            .put("notifContent", Policy.notifContent(a))
            .put("redirects", red)
            .put("keymap", JSONArray(Policy.keymapJson(a)))
            .put("unread", if (mode() == "adult") Notices.unread else 0)
            .put("sdk", Build.VERSION.SDK_INT)
            .put("release", Build.VERSION.RELEASE)
            .put("patch", Build.VERSION.SECURITY_PATCH)
            .put("patchOld", KidsGuardService.patchOld())
            .put("bed", Policy.bedtime(a))
            .put("contPerm", contPerm())
            .put("recents", JSONArray(Policy.current(a)?.let { if (it.recents) Policy.recents(a, it.id) else emptyList() } ?: emptyList<String>()))
            .toString()
    }

    // ---------- şifre ----------
    /** "ok" | "bad" | "lock:<sn>" */
    @JavascriptInterface
    fun checkPin(pin: String): String {
        val r = Policy.checkPin(a, pin)
        return if (r == 0) "ok" else if (r < 0) "bad" else "lock:$r"
    }

    @JavascriptInterface
    fun setPin(pin: String, old: String): Boolean {
        if (pin.length != 4 || !pin.all { it.isDigit() }) return false
        if (Policy.hasPin(a) && !auth(old)) return false
        Policy.setPin(a, pin)
        return true
    }

    // ---------- profiller ----------
    /** "ok" | "bad_pin" | "lock:<sn>" | "no_guard" | "denied" */
    @JavascriptInterface
    fun selectProfile(id: String, pin: String): String {
        val p = Policy.profiles(a).firstOrNull { it.id == id } ?: return "denied"
        val needPin = when (p.type) {
            "adult" -> Policy.multi(a) && Policy.hasPin(a)
            "easy" -> p.pinReq && Policy.hasPin(a)
            else -> false
        }
        if (p.type == "kids" && !KidsGuardService.enabled(a)) return "no_guard"
        if (needPin) {
            val r = Policy.checkPin(a, pin)
            if (r < 0) return "bad_pin"
            if (r > 0) return "lock:$r"
        }
        Policy.setActive(a, id)
        return "ok"
    }

    /** Profil oluştur veya güncelle. Sadece yetişkin profilinde (veya şifreyle). */
    @JavascriptInterface
    fun profileSave(json: String, pin: String): String {
        if (!auth(pin)) return "denied"
        val np = try { Profile.from(JSONObject(json)) } catch (_: Throwable) { null } ?: return "bad"
        val l = Policy.profiles(a).toMutableList()
        val idx = l.indexOfFirst { it.id == np.id }
        if (idx < 0) {
            if (l.size >= Profile.MAX) return "full"
            if (np.type != "adult" && !Policy.hasPin(a)) return "no_pin"
            l.add(np)
        } else {
            val old = l[idx]
            if (old.type == "adult" && np.type != "adult" && l.count { it.type == "adult" } == 1) return "last_adult"
            l[idx] = np
        }
        Policy.saveProfiles(a, l)
        return "ok"
    }

    @JavascriptInterface
    fun profileDelete(id: String, pin: String): String {
        if (!auth(pin)) return "denied"
        val l = Policy.profiles(a).toMutableList()
        val p = l.firstOrNull { it.id == id } ?: return "bad"
        if (p.type == "adult" && l.count { it.type == "adult" } == 1) return "last_adult"
        l.remove(p)
        Policy.saveProfiles(a, l)
        if (Policy.activeId(a) == id) Policy.setActive(a, l.first { it.type == "adult" }.id)
        return "ok"
    }

    // ---------- çocuk profilinde uygulama sırası ----------
    /** Çocuk kendi profilindeki sırayı değiştirebilir; yalnızca sıra değişir, hiçbir uygulama eklenmez veya çıkarılmaz. */
    @JavascriptInterface
    fun reorderApps(json: String): Boolean {
        if (mode() != "kids") return false
        val p = Policy.current(a) ?: return false
        val sub = ArrayList<String>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) sub.add(arr.optString(i))
        } catch (_: Throwable) { return false }
        if (sub.toSet().size != sub.size || !p.apps.containsAll(sub)) return false
        val order = LinkedHashSet<String>(sub)
        order.addAll(p.apps) // gönderilmeyenler sona eklenir, hiçbiri silinmez
        Policy.saveProfiles(a, Policy.profiles(a).map { if (it.id == p.id) it.copy(apps = order) else it })
        return true
    }

    /** Uygulamayı profilden kaldırmak ebeveyn şifresi ister (çocuk profilinde şifresiz çalışmaz). */
    @JavascriptInterface
    fun removeApp(pkg: String, pin: String): Boolean {
        if (!auth(pin)) return false
        val p = Policy.current(a) ?: return false
        if (pkg !in p.apps) return false
        val rest = LinkedHashSet<String>(p.apps)
        rest.remove(pkg)
        Policy.saveProfiles(a, Policy.profiles(a).map { if (it.id == p.id) it.copy(apps = rest) else it })
        return true
    }

    // ---------- çocuk süre sınırı ----------
    @JavascriptInterface
    fun setLimit(on: Boolean, min: Int, pin: String): Boolean {
        if (!auth(pin)) return false
        Policy.setLimit(a, on, min)
        return true
    }

    @JavascriptInterface
    fun addBonus(pin: String): Boolean { if (!auth(pin)) return false; Policy.addBonus(a); return true }

    @JavascriptInterface
    fun resetToday(pin: String): Boolean { if (!auth(pin)) return false; Policy.resetToday(a); return true }

    // ---------- ana sayfa devralma ve yönlendirme ----------
    @JavascriptInterface
    fun setHomeOverride(on: Boolean, pin: String): Boolean { if (!auth(pin)) return false; Policy.setHomeOverride(a, on); return true }

    /** Google TV'nin kendi ana ekranını 60 sn boyunca açık bırakır ve açar (yalnızca yetişkin). */
    @JavascriptInterface
    fun stockHome(): Boolean {
        if (!adultOnly()) return false
        val home = a.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .firstOrNull { it.activityInfo.packageName != a.packageName } ?: return false
        Policy.markBypass(a, 60000)
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .setClassName(home.activityInfo.packageName, home.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        a.runOnUiThread { try { a.startActivity(i) } catch (_: Throwable) { } }
        return true
    }

    @JavascriptInterface
    fun setRedirects(json: String, pin: String): Boolean {
        if (!auth(pin)) return false
        return try {
            val arr = JSONArray(json)
            val m = LinkedHashMap<String, String>()
            for (i in 0 until minOf(arr.length(), 20)) {
                val o = arr.getJSONObject(i)
                val f = o.optString("from").take(150); val t = o.optString("to").take(150)
                if (f.isNotEmpty() && t.isNotEmpty() && f != t && f != a.packageName && t != a.packageName) m[f] = t
            }
            Policy.setRedirects(a, m)
            true
        } catch (_: Throwable) { false }
    }

    /** Kumandadan açılan son yabancı uygulama (yönlendirme eklerken yardımcı). */
    @JavascriptInterface
    fun foreign(): String {
        val p = Policy.lastForeign(a)
        if (p.isEmpty()) return ""
        val n = try { a.packageManager.getApplicationLabel(a.packageManager.getApplicationInfo(p, 0)).toString() } catch (_: Throwable) { p }
        return JSONObject().put("pkg", p).put("n", n).toString()
    }

    // ---------- tuş atama ----------
    @JavascriptInterface
    fun setKeymap(json: String, pin: String): Boolean {
        if (!auth(pin)) return false
        return try {
            val arr = JSONArray(json)
            val out = JSONArray()
            val ok = setOf("app", "quick", "voice", "home", "sleep")
            for (i in 0 until minOf(arr.length(), 30)) {
                val o = arr.getJSONObject(i)
                val act = o.optString("action")
                if (act !in ok) continue
                val arg = o.optString("arg").take(150)
                if (act == "app" && arg.isEmpty()) continue
                out.put(JSONObject().put("kc", o.optInt("kc")).put("sc", o.optInt("sc")).put("long", o.optBoolean("long"))
                    .put("action", act).put("arg", arg).put("label", o.optString("label").take(40)))
            }
            Policy.setKeymapJson(a, out.toString())
            true
        } catch (_: Throwable) { false }
    }

    @JavascriptInterface
    fun setKeyMapOn(on: Boolean, pin: String): Boolean { if (!auth(pin)) return false; Policy.setKeyMapOn(a, on); return true }

    @JavascriptInterface
    fun learnStart(): Boolean { if (!adultOnly()) return false; Policy.learnStart(a); return true }

    @JavascriptInterface
    fun learnLast(): String = if (adultOnly()) Policy.lastKey(a) else ""

    @JavascriptInterface
    fun learnStop() { Policy.learnStop(a) }

    // ---------- bildirimler ----------
    @JavascriptInterface
    fun notifs(): String {
        val arr = JSONArray()
        if (!adultOnly()) return arr.toString()
        val showText = Policy.notifContent(a)
        for (n in Notices.all()) {
            arr.put(JSONObject().put("id", n.id).put("own", n.own).put("app", n.app).put("title", n.title)
                .put("text", if (n.own || showText) n.text else "").put("t", n.time))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun notifOpen(id: Long): Boolean {
        if (!adultOnly()) return false
        val n = Notices.find(id) ?: return false
        Notices.remove(id)
        n.key?.let { NotifService.cancelKey(it) }
        val pi = n.intent ?: return true
        Policy.markLaunch(a)
        a.runOnUiThread { try { pi.send() } catch (_: Throwable) { } }
        return true
    }

    @JavascriptInterface
    fun notifDismiss(id: Long) {
        if (!adultOnly()) return
        Notices.find(id)?.key?.let { NotifService.cancelKey(it) }
        Notices.remove(id)
    }

    @JavascriptInterface
    fun notifClear() { if (adultOnly()) Notices.clear() }

    @JavascriptInterface
    fun notifSeen() { if (adultOnly()) Notices.seen() }

    @JavascriptInterface
    fun setDnd(on: Boolean) { if (adultOnly()) Policy.setDnd(a, on) }

    @JavascriptInterface
    fun setNotifContent(on: Boolean, pin: String): Boolean { if (!auth(pin)) return false; Policy.setNotifContent(a, on); return true }

    // ---------- sesli arama, uyku, klavye ----------
    @JavascriptInterface
    fun voice(): Boolean {
        val m = mode()
        if (m != "adult" && m != "easy") return false
        a.runOnUiThread { Util.voice(a) }
        return true
    }

    @JavascriptInterface
    fun sleepTimer(min: Int): Boolean {
        if (mode() == "picker") return false
        if (min <= 0) { Policy.setSleepAt(a, 0); return true }
        Policy.setSleepAt(a, System.currentTimeMillis() + min.coerceAtMost(240) * 60000L)
        return true
    }

    @JavascriptInterface
    fun sleepLeft(): Int {
        val t = Policy.sleepAt(a)
        return if (t <= 0) 0 else ceil((t - System.currentTimeMillis()) / 60000.0).toInt().coerceAtLeast(0)
    }

    @JavascriptInterface
    fun keyboard() { a.showIme() }

    // ---------- sistem ekranları (yalnızca yetişkin) ----------
    @JavascriptInterface
    fun openA11y(): Boolean {
        if (!adultOnly()) return false
        return Util.startFirst(a, listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), Intent(Settings.ACTION_SETTINGS)))
    }

    @JavascriptInterface
    fun openNotifAccess(): Boolean {
        if (!adultOnly()) return false
        return Util.startFirst(a, listOf(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), Intent(Settings.ACTION_SETTINGS)))
    }

    /** Uygulama bilgisi ekranı (oradan "Zorla durdur" yapılır). Yalnızca yetişkin; Android sürümünden bağımsız çalışır. */
    @JavascriptInterface
    fun appInfo(pkg: String): Boolean {
        if (!adultOnly() || pkg.isEmpty() || pkg == a.packageName) return false
        if (Util.launchIntent(a, pkg) == null) return false
        return Util.startFirst(a, listOf(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
            Intent(Settings.ACTION_SETTINGS)
        ))
    }

    @JavascriptInterface
    fun openSystemSettings(): Boolean {
        if (!adultOnly()) return false
        return Util.startFirst(a, listOf(Intent(Settings.ACTION_SETTINGS)))
    }
}
