package com.abert.tv.ui

/** Ana ekranın verisi (profil ayarlarından ve uygulama listesinden üretilir). */
class Tile(
    val id: String, val label: String, val sub: String, val color: Int, val glyph: String,
    val kind: Int,                       // 0 uygulama, 1 devam et, 2 klasör, 3 bağlantı
    val pct: Int = 0, val minis: List<Pair<Int, String>> = emptyList()
)

class Row(val title: String, val tiles: List<Tile>)

class TopIcon(val name: String, val sub: String, val path: String, val badge: Int = 0, val letter: String? = null, val color: Int = 0)

class HomeData(
    val greeting: String, val clock: String,
    val top: List<TopIcon>, val rows: List<Row>,
    val light: Boolean, val tileSize: Int, val hero: Boolean, val labels: Int, val textScale: Float
)

/**
 * Yerel ana ekran sahnesi: yerleşim ve çizim burada, Android'e bağımlı değil (Gfx soyutlaması).
 * Tasarım uzayı 1920 genişliktir; gerçek boyuta ölçeklenir.
 * Odak: fr = 0 üst çubuk, fr >= 1 satırlar; fc sütun.
 */
class HomeScene(var data: HomeData) {
    var fr = 1
    var fc = 0

    private val W = 1920f
    private val M = 115f
    private val GAP = 30f
    private val iconCache = HashMap<String, List<PathCmd>>()

    private class Pal(
        val bg: Int, val text: Int, val muted: Int, val ctl: Int, val ctlText: Int, val ctlF: Int, val ctlFText: Int, val glow: Float
    )

    private fun pal(): Pal = if (data.light)
        Pal(0xFFEEF0F4.toInt(), 0xFF0F1320.toInt(), Col.withAlpha(0xFF0F1320.toInt(), .62f), Col.withAlpha(0xFF0F1320.toInt(), .09f), 0xFF1A2030.toInt(), 0xFF14182A.toInt(), 0xFFFFFFFF.toInt(), .38f)
    else
        Pal(0xFF080B12.toInt(), 0xFFF5F5F7.toInt(), Col.withAlpha(0xFFF5F5F7.toInt(), .62f), Col.withAlpha(0xFFFFFFFF.toInt(), .13f), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF0A0E16.toInt(), .55f)

    private fun perRow() = intArrayOf(6, 5, 4, 3)[data.tileSize.coerceIn(0, 3)]
    private fun tileW(t: Tile): Float = if (t.kind == 0 || t.kind == 2) (W - 2 * M - (perRow() - 1) * GAP) / perRow() else 460f
    private fun tileH(t: Tile): Float = if (t.kind == 0 || t.kind == 2) tileW(t) * 0.625f else 150f
    private fun labelSpace(t: Tile) = if (t.kind == 0 || t.kind == 2) 76f else 30f
    private fun rowHeight(r: Row): Float {
        val t = r.tiles.firstOrNull() ?: return 120f
        return 56f + tileH(t) + labelSpace(t)
    }

    private fun focusTile(): Tile? = if (fr >= 1) data.rows.getOrNull(fr - 1)?.tiles?.getOrNull(fc) else null

    fun draw(g: Gfx, pw: Int, ph: Int) {
        val s = pw / W
        val H = ph / s
        val p = pal()
        g.save()
        g.scale(s, s)
        g.fillRect(0f, 0f, W, H, p.bg)
        val fTile = focusTile()
        val ambient = fTile?.color ?: 0xFF1F8F7A.toInt()
        g.glow(300f, 120f, 1000f, Col.withAlpha(ambient, p.glow))
        g.fillRRectGrad(0f, 0f, W, H, 0f, Col.withAlpha(p.bg, .12f), p.bg)
        drawTop(g, p)
        if (data.hero) drawHero(g, p, fTile)
        drawRows(g, p, H)
        g.restore()
    }

    // ---------- üst çubuk ----------
    private fun drawTop(g: Gfx, p: Pal) {
        val ts = data.textScale
        g.text(data.greeting, M, 64f, 22f * ts, p.muted, 400, 0)
        val clockW = g.measure(data.clock, 24f * ts, 400)
        val clockX = W - M
        g.text(data.clock, clockX, 64f, 24f * ts, p.text, 400, 2)
        var xr = clockX - clockW - 34f
        for (k in data.top.indices.reversed()) {
            val ic = data.top[k]
            val d = 56f
            val x = xr - d
            val focus = fr == 0 && fc == k
            drawTopIcon(g, p, ic, x, 32f, d, focus)
            xr = x - 16f
        }
    }

    private fun drawTopIcon(g: Gfx, p: Pal, ic: TopIcon, x: Float, y: Float, d: Float, focus: Boolean) {
        g.save()
        if (focus) { g.translate(x + d / 2, y + d / 2); g.scale(1.14f, 1.14f); g.translate(-(x + d / 2), -(y + d / 2)) }
        val cx = x + d / 2; val cy = y + d / 2
        if (ic.letter != null) {
            g.fillCircle(cx, cy, d / 2, if (ic.color != 0) ic.color else 0xFF1F8F7A.toInt())
            g.text(ic.letter, cx, cy + 9f, 26f * data.textScale, 0xFFFFFFFF.toInt(), 600, 1)
        } else {
            g.fillCircle(cx, cy, d / 2, if (focus) p.ctlF else p.ctl)
            val cmds = iconCache.getOrPut(ic.path) { SvgPath.parse(ic.path) }
            g.icon(cmds, cx - 15f, cy - 15f, 30f, if (focus) p.ctlFText else p.ctlText)
        }
        if (focus && ic.letter != null) g.strokeRRect(x - 3f, y - 3f, d + 6f, d + 6f, d / 2 + 3f, p.text, 3f)
        if (ic.badge > 0) {
            g.fillCircle(x + d - 6f, y + 6f, 12f, 0xFFE5392F.toInt())
            g.text(if (ic.badge > 9) "9+" else ic.badge.toString(), x + d - 6f, y + 11f, 14f, 0xFFFFFFFF.toInt(), 600, 1)
        }
        g.restore()
    }

    // ---------- büyük başlık ----------
    private fun drawHero(g: Gfx, p: Pal, t: Tile?) {
        val ts = data.textScale
        val title: String; val sub: String
        if (t != null) { title = t.label; sub = if (t.sub.isNotEmpty()) t.sub else "Uygulama" }
        else { val ic = data.top.getOrNull(fc); title = ic?.name ?: ""; sub = ic?.sub ?: "" }
        g.text(fit(g, title, 96f * ts, 300, 1150f), M, 250f, 96f * ts, p.text, 300, 0)
        g.text(fit(g, sub, 30f * ts, 400, 1150f), M, 300f, 30f * ts, p.muted, 400, 0)
        val bw = 112f
        g.fillRRect(M, 330f, bw, 46f, 23f, p.ctl)
        g.strokeRRect(M, 330f, bw, 46f, 23f, Col.withAlpha(p.text, .22f), 1.5f)
        g.text("Aç", M + bw / 2, 361f, 22f, p.text, 400, 1)
    }

    private fun fit(g: Gfx, s: String, size: Float, weight: Int, maxW: Float): String {
        if (g.measure(s, size, weight) <= maxW) return s
        var e = s.length
        while (e > 1 && g.measure(s.substring(0, e) + "…", size, weight) > maxW) e--
        return s.substring(0, e) + "…"
    }

    // ---------- satırlar ----------
    private fun drawRows(g: Gfx, p: Pal, H: Float) {
        val top = if (data.hero) 440f else 150f
        g.save()
        g.clipRect(0f, top, W, H - top)
        // kaydırma: odaklanan satır pencerenin başına gelir
        var y = 0f
        val tops = FloatArray(data.rows.size)
        for (i in data.rows.indices) { tops[i] = y; y += rowHeight(data.rows[i]) + 22f }
        val scroll = if (fr >= 1 && fr - 1 < tops.size) tops[fr - 1] else 0f
        for (i in data.rows.indices) {
            val r = data.rows[i]
            val ry = top + 24f + tops[i] - scroll
            val focusRow = fr == i + 1
            g.save()
            if (!focusRow) g.alpha(.55f)
            g.text(r.title, M, ry + 22f, 24f * data.textScale, p.muted, 600, 0)
            val tyBase = ry + 44f
            // yatay kaydırma
            var xo = 0f
            if (focusRow) {
                var xx = M
                for ((k, t) in r.tiles.withIndex()) {
                    val w = tileW(t)
                    if (k == fc) xo = maxOf(0f, xx + w - (W - M))
                    xx += w + GAP
                }
            }
            var x = M - xo
            for ((k, t) in r.tiles.withIndex()) {
                val w = tileW(t); val h = tileH(t)
                if (x + w > 0 && x < W) drawTile(g, p, t, x, tyBase, w, h, focusRow && k == fc)
                x += w + GAP
            }
            g.restore()
        }
        g.restore()
    }

    private fun drawTile(g: Gfx, p: Pal, t: Tile, x: Float, y: Float, w: Float, h: Float, focus: Boolean) {
        val ts = data.textScale
        g.save()
        if (focus) {
            g.translate(x + w / 2, y + h / 2); g.scale(1.08f, 1.08f); g.translate(-(x + w / 2), -(y + h / 2))
            for (k in 1..4) g.fillRRect(x - k * 3f, y + 14f - k * 2f + k * 3f, w + k * 6f, h + k * 3f, 26f + k * 3f, Col.withAlpha(0xFF000000.toInt(), .07f))
        }
        val r = 22f
        when (t.kind) {
            0 -> {
                g.fillRRectGrad(x, y, w, h, r, Col.shade(t.color, .2f), Col.shade(t.color, -.4f))
                g.text(t.glyph, x + w / 2, y + h / 2 + h * 0.18f, h * 0.5f, Col.withAlpha(0xFFFFFFFF.toInt(), .9f), 400, 1)
                val showLabel = data.labels == 0 || (data.labels == 1 && focus)
                if (showLabel) g.text(fit(g, t.label, 26f * ts, 600, w), x + w / 2, y + h + 42f, 26f * ts, p.text, 600, 1)
            }
            1 -> {
                g.fillRRectGrad(x, y, w, h, r, Col.shade(t.color, .15f), Col.shade(t.color, -.35f))
                g.text(fit(g, t.label, 28f * ts, 600, w - 40f), x + 20f, y + h - 66f, 28f * ts, 0xFFFFFFFF.toInt(), 600, 0)
                g.text(fit(g, t.sub, 20f * ts, 400, w - 40f), x + 20f, y + h - 38f, 20f * ts, Col.withAlpha(0xFFFFFFFF.toInt(), .85f), 400, 0)
                g.fillRRect(x + 20f, y + h - 22f, w - 40f, 5f, 2.5f, Col.withAlpha(0xFFFFFFFF.toInt(), .25f))
                g.fillRRect(x + 20f, y + h - 22f, (w - 40f) * t.pct.coerceIn(0, 100) / 100f, 5f, 2.5f, 0xFFFFFFFF.toInt())
            }
            2 -> {
                g.fillRRect(x, y, w, h, r, if (data.light) Col.withAlpha(0xFFFFFFFF.toInt(), .75f) else Col.withAlpha(0xFFFFFFFF.toInt(), .14f))
                val sq = h * 0.34f; val gp = h * 0.07f
                val gx = x + (w - (2 * sq + gp)) / 2; val gy = y + (h - (2 * sq + gp)) / 2
                for ((k, m) in t.minis.take(4).withIndex()) {
                    val mx = gx + (k % 2) * (sq + gp); val my = gy + (k / 2) * (sq + gp)
                    g.fillRRectGrad(mx, my, sq, sq, sq * 0.24f, Col.shade(m.first, .18f), Col.shade(m.first, -.25f))
                    g.text(m.second, mx + sq / 2, my + sq / 2 + sq * 0.17f, sq * 0.48f, 0xFFFFFFFF.toInt(), 600, 1)
                }
                g.text(fit(g, t.label + " · " + t.sub, 26f * ts, 600, w + 30f), x + w / 2, y + h + 42f, 26f * ts, p.text, 600, 1)
            }
            else -> {
                g.fillRRectGrad(x, y, w, h, r, Col.shade(t.color, .15f), Col.shade(t.color, -.35f))
                g.text(fit(g, t.label, 30f * ts, 600, w - 40f), x + 22f, y + h - 62f, 30f * ts, 0xFFFFFFFF.toInt(), 600, 0)
                g.text(fit(g, t.sub, 20f * ts, 400, w - 40f), x + 22f, y + h - 30f, 20f * ts, Col.withAlpha(0xFFFFFFFF.toInt(), .8f), 400, 0)
            }
        }
        if (focus) g.strokeRRect(x, y, w, h, r, if (data.light) 0xFF0F1320.toInt() else 0xFFFFFFFF.toInt(), 3.5f)
        g.restore()
    }
}
