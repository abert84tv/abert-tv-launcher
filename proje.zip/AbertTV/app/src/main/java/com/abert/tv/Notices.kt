package com.abert.tv

import android.app.PendingIntent

/** Bildirim merkezi: yalnızca bellekte tutulur, diske yazılmaz, internete gönderilmez. */
object Notices {
    class Item(
        val id: Long,
        val own: Boolean,
        val pkg: String,
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val key: String?,
        val intent: PendingIntent?
    )

    private val list = ArrayList<Item>()
    private var seq = 0L
    @Volatile var unread = 0
        private set

    @Synchronized
    private fun push(own: Boolean, pkg: String, app: String, title: String, text: String, key: String?, pi: PendingIntent?) {
        if (key != null) list.removeAll { it.key == key }
        list.add(0, Item(++seq, own, pkg, app, title, text, System.currentTimeMillis(), key, pi))
        while (list.size > 60) list.removeAt(list.size - 1)
        unread = list.size.coerceAtMost(unread + 1)
    }

    fun addOwn(title: String, text: String) = push(true, "", "Abert TV", title, text, null, null)
    fun addSystem(pkg: String, app: String, title: String, text: String, key: String, pi: PendingIntent?) =
        push(false, pkg, app, title, text, key, pi)

    @Synchronized fun all(): List<Item> = ArrayList(list)
    @Synchronized fun find(id: Long): Item? = list.firstOrNull { it.id == id }
    @Synchronized fun remove(id: Long) { list.removeAll { it.id == id }; unread = unread.coerceAtMost(list.size) }
    @Synchronized fun removeKey(key: String) { list.removeAll { it.key == key }; unread = unread.coerceAtMost(list.size) }
    @Synchronized fun clear() { list.clear(); unread = 0 }
    @Synchronized fun seen() { unread = 0 }
}
