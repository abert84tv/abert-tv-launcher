package com.abert.tv

import android.app.Application
import android.os.SystemClock

/** Çökmeleri sayar: kısa sürede üst üste çökerse launcher güvenli moda geçer (Google ana ekranına döner). */
class App : Application() {
    companion object {
        /** Sürecin başlangıç zamanı ve ana ekranın ilk hazır olduğu an (açılış süresi ölçümü). */
        @Volatile var t0 = 0L
        @Volatile var readyMs = 0L
    }

    override fun onCreate() {
        super.onCreate()
        t0 = SystemClock.elapsedRealtime()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Policy.noteCrash(this) } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
