package com.abert.tv

import android.app.Application

/** Çökmeleri sayar: kısa sürede üst üste çökerse launcher güvenli moda geçer (Google ana ekranına döner). */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Policy.noteCrash(this) } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
