package com.abert.tv

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

object Util {
    /** Bir erişilebilirlik servisi gerçekten açık mı? */
    fun a11yEnabled(c: Context, cls: Class<*>): Boolean {
        val v = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(c, cls)
        val on = v.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
        return on && Settings.Secure.getInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
    }

    fun notifAccessEnabled(c: Context): Boolean {
        val v = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        val cn = ComponentName(c, NotifService::class.java)
        return v.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    private val intentCache = java.util.concurrent.ConcurrentHashMap<String, Intent>()
    fun clearIntentCache() { intentCache.clear() }

    /** Uygulama açma niyeti önbellekten gelir (her seferinde paket yöneticisine sorulmaz). */
    fun launchIntent(c: Context, pkg: String): Intent? {
        intentCache[pkg]?.let { return Intent(it) }
        val pm = c.packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return null
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intentCache[pkg] = i
        return Intent(i)
    }

    /** İlk çözülebilen niyeti başlatır. */
    fun startFirst(c: Context, intents: List<Intent>): Boolean {
        for (i in intents) {
            try {
                if (i.resolveActivity(c.packageManager) != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(i)
                    return true
                }
            } catch (_: Throwable) {
            }
        }
        return false
    }

    /** method: 0 otomatik, 1 Google Asistan, 2 Arama tuşu (kumandadaki mikrofon gibi), 3 sesle ara. */
    fun voice(c: Context, method: Int = 0): Boolean {
        val sl = Intent("android.intent.action.SEARCH_LONG_PRESS")
        val va = Intent("android.intent.action.VOICE_ASSIST")
        val asst = Intent(Intent.ACTION_ASSIST)
        val vc = Intent(Intent.ACTION_VOICE_COMMAND)
        val ws = Intent("android.speech.action.WEB_SEARCH")
        val list = when (method) {
            1 -> listOf(va, asst)
            2 -> listOf(sl)
            3 -> listOf(ws)
            else -> listOf(sl, va, asst, vc, ws)
        }
        return startFirst(c, list)
    }

    fun openLauncher(c: Context) {
        try {
            c.startActivity(
                Intent(c, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Throwable) {
        }
    }

    fun openQuick(c: Context) {
        try {
            c.startActivity(
                Intent(c, MainActivity::class.java).putExtra("open", "quick")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Throwable) {
        }
    }
}
