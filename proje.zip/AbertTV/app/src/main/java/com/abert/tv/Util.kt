package com.abert.tv

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

object Util {
    /** Bir erişilebilirlik servisi gerçekten açık mı? */
    fun a11yEnabled(c: Context, cls: Class<*>): Boolean {
        val v = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(c, cls)
        val on = v.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
        return on && Settings.Secure.getInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
    }

    fun notifAccessEnabled(c: Context): Boolean {
        val v = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        val cn = ComponentName(c, NotifService::class.java)
        return v.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    fun launchIntent(c: Context, pkg: String): Intent? {
        val pm = c.packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return null
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** İlk çözülebilen niyeti başlatır. */
    fun startFirst(c: Context, intents: List<Intent>): Boolean {
        for (i in intents) {
            try {
                if (i.resolveActivity(c.packageManager) != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(i)
                    return true
                }
            } catch (_: Throwable) {
            }
        }
        return false
    }

    fun voice(c: Context): Boolean = startFirst(
        c, listOf(
            Intent("android.intent.action.VOICE_ASSIST"),
            Intent(Intent.ACTION_ASSIST),
            Intent(Intent.ACTION_VOICE_COMMAND),
            Intent("android.speech.action.WEB_SEARCH")
        )
    )

    fun openLauncher(c: Context) {
        try {
            c.startActivity(
                Intent(c, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Throwable) {
        }
    }

    fun openQuick(c: Context) {
        try {
            c.startActivity(
                Intent(c, MainActivity::class.java).putExtra("open", "quick")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Throwable) {
        }
    }
}
