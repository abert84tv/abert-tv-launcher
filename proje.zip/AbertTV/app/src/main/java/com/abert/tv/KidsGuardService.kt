package com.abert.tv

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tek bir erişilebilirlik servisi, dört iş:
 *  1) Çocuk profili ve profil seçim ekranında izinsiz uygulamayı anında geri atar.
 *  2) Ana Sayfa devralma: Google TV'nin kendi ana ekranı açılırsa bu launcher'ı getirir.
 *  3) Uygulama yönlendirme: kumandanın Netflix gibi sabit tuşunun açtığı uygulamayı seçtiğin uygulamaya çevirir.
 *  4) Uyku, süre uyarıları ve profil seçimine dönüş.
 * Yalnızca "hangi pencere açıldı" bilgisini görür; ekran içeriğini ve tuşları okumaz.
 */
/** Ana Sayfa teşhisi: son pencere olayları yalnızca bellekte tutulur (diske yazılmaz, hiçbir yere gönderilmez). */
object Diag {
    private val q = java.util.ArrayDeque<String>()
    @Synchronized fun add(pkg: String, cls: String?, stock: Boolean, takeover: Boolean) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        q.addFirst("$t  ${pkg.substringAfterLast('.')}/${(cls ?: "?").substringAfterLast('.')}  ${if (stock) "ANA EKRAN" else ""}${if (stock && takeover) " → devralındı" else ""}")
        while (q.size > 14) q.removeLast()
    }
    @Synchronized fun dump(): List<String> = q.toList()
    @Synchronized fun clear() { q.clear() }
}

class KidsGuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastPkg = ""
    private var lastKick = 0L
    private var registered = false
    private var homesAt = 0L
    private var homes: Set<String> = emptySet()
    private var patchChecked = false

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 5000)
        }
    }

    private val wake = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { toPicker() }
    }

    override fun onServiceConnected() {
        Policy.reapplyDream(this)
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 5000)
        try {
            if (registered) unregisterReceiver(wake)
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_DREAMING_STARTED)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(wake, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(wake, f)
            registered = true
        } catch (_: Throwable) {
        }
        toPicker()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        try { if (registered) unregisterReceiver(wake) } catch (_: Throwable) { }
        registered = false
        super.onDestroy()
    }

    /** Birden çok profil varsa profil seçimi; tek profil varsa doğrudan o profil. */
    private fun toPicker() {
        if (Policy.multi(this)) {
            Policy.setActive(this, "picker")
            Util.openLauncher(this)
        } else {
            Policy.setActive(this, Policy.profiles(this).first().id)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg in IGNORE || isIme(pkg)) return
        lastPkg = pkg
        if (pkg != packageName) Policy.setLastForeign(this, pkg)
        Diag.add(pkg, e.className?.toString(), isStockHome(pkg, e.className?.toString()), Policy.homeOverride(this) && System.currentTimeMillis() > Policy.bypassUntil(this))
        enforce(pkg, e.className?.toString())
    }

    private fun isIme(pkg: String): Boolean = try {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.any { it.packageName == pkg }
    } catch (t: Throwable) { false }

    /** Sistemin ana ekran etkinlikleri ("paket/sınıf"). Yalnızca bunlar devralınır; Google TV'nin profil seçici
     *  gibi diğer pencerelerine dokunulmaz. */
    private fun stockHomes(): Set<String> {
        val n = System.currentTimeMillis()
        if (n - homesAt > 60000) {
            homesAt = n
            homes = try {
                packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map { it.activityInfo.packageName + "/" + it.activityInfo.name }.toSet()
            } catch (t: Throwable) { emptySet() }
        }
        return homes
    }

    private fun isStockHome(pkg: String, cls: String?): Boolean {
        val h = stockHomes()
        if (if (cls == null) h.any { it.startsWith("$pkg/") } else (pkg + "/" + cls) in h) return true
        // Yedek kural: bilinen Google TV ana ekran paketlerinin "Home" adlı etkinlikleri (sistem listesi boş dönerse)
        return pkg in KNOWN_HOMES && cls != null && cls.contains("Home", ignoreCase = true)
    }

    private fun enforce(pkg: String, cls: String?) {
        if (pkg == packageName) return
        val now = System.currentTimeMillis()
        val mode = Policy.mode(this)

        // Google TV'nin kendi ana ekranı geldiyse bizim ana ekrana dön.
        if (Policy.homeOverride(this) && now > Policy.bypassUntil(this) && isStockHome(pkg, cls)) {
            Util.openLauncher(this)
            return
        }
        when (mode) {
            "adult" -> redirect(pkg)
            "easy" -> if (pkg in Policy.STOCK_SETTINGS) Util.openLauncher(this) else redirect(pkg)
            "picker" -> kick()
            "kids" -> {
                val p = Policy.current(this)
                val ok = p != null && !Policy.timeUp(this) && !Policy.bedtime(this) && pkg in p.apps
                if (!ok) kick()
            }
        }
    }

    /** Sabit uygulama tuşunun açtığı uygulamayı seçilen uygulamaya yönlendirir. */
    private fun redirect(pkg: String) {
        val to = Policy.redirects(this)[pkg] ?: return
        if (Policy.recentLaunch(this, 4000)) return // Launcher'ın kendi açtığı uygulamaya dokunma
        val i = Util.launchIntent(this, to) ?: return
        Policy.markLaunch(this)
        try { startActivity(i) } catch (_: Throwable) { }
    }

    private fun kick() {
        val now = System.currentTimeMillis()
        if (now - lastKick < 300) return
        lastKick = now
        Util.openLauncher(this)
        handler.postDelayed({
            if (lastPkg != packageName && Policy.mode(this) != "adult") Util.openLauncher(this)
        }, 400)
    }

    private fun toast(t: String) { handler.post { try { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } catch (_: Throwable) { } } }

    private fun tick() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        val now = System.currentTimeMillis()

        // uyku zamanlayıcı
        val sl = Policy.sleepAt(this)
        if (sl in 1..now) {
            Policy.setSleepAt(this, 0)
            Notices.addOwn("Uyku zamanlayıcı", "Süre doldu, TV uykuya alınıyor")
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }

        // güvenlik yaması eskiyse bir kez uyar
        if (!patchChecked) {
            patchChecked = true
            if (patchOld()) Notices.addOwn("Güvenlik yaması eski", "TV'nin güvenlik yaması 6 aydan eski. Sistem güncellemesini kontrol edin")
        }

        val mode = Policy.mode(this)
        if (mode == "kids") {
            Policy.addUsed(this, 5)
            if (Policy.limitOn(this)) {
                val left = Policy.leftSec(this)
                if (left in 1..60 && !Policy.warned(this, "warn1")) {
                    Policy.markWarned(this, "warn1")
                    Notices.addOwn("Süre bitmek üzere", "Çocuk profilinde 1 dakika kaldı")
                    toast("Kalan süre 1 dakika")
                } else if (left in 61..600 && !Policy.warned(this, "warn10")) {
                    Policy.markWarned(this, "warn10")
                    Notices.addOwn("Süre azalıyor", "Çocuk profilinde 10 dakika kaldı")
                    toast("Kalan süre 10 dakika")
                }
            }
            if ((Policy.timeUp(this) || Policy.bedtime(this)) && lastPkg != packageName) kick()
        } else if (mode == "picker" && lastPkg != packageName) kick()
    }

    companion object {
        private val IGNORE = setOf("com.android.systemui", "android")
        private val KNOWN_HOMES = setOf("com.google.android.apps.tv.launcherx", "com.google.android.tvlauncher", "com.google.android.leanbacklauncher")

        fun enabled(c: Context) = Util.a11yEnabled(c, KidsGuardService::class.java)

        fun patchOld(): Boolean = try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)
            d != null && Date().time - d.time > 183L * 24 * 3600 * 1000
        } catch (_: Throwable) { false }
    }
}
