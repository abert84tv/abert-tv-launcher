package com.abert.tv

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** İSTEĞE BAĞLI bildirim erişimi. Bildirimler yalnızca bellekte tutulur, diske yazılmaz, internete gönderilmez. */
class NotifService : NotificationListenerService() {
    override fun onListenerConnected() {
        instance = this
        try { activeNotifications?.forEach { take(it, false) } } catch (_: Throwable) { }
    }

    override fun onListenerDisconnected() { if (instance === this) instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification?) { if (sbn != null) take(sbn, true) }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { if (sbn != null) Notices.removeKey(sbn.key) }

    private fun take(sbn: StatusBarNotification, fresh: Boolean) {
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.packageName in Policy.notifDenied(this)) return
        val ex = n.extras
        val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Throwable) { sbn.packageName }
        Notices.addSystem(sbn.packageName, label, title.take(80), text.take(160), sbn.key, n.contentIntent)
    }

    companion object {
        @Volatile var instance: NotifService? = null
        fun cancelKey(key: String) { try { instance?.cancelNotification(key) } catch (_: Throwable) { } }
    }
}
