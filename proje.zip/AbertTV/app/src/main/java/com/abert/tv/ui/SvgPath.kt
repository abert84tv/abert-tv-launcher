package com.abert.tv.ui

import kotlin.math.*

sealed class PathCmd {
    class M(val x: Float, val y: Float) : PathCmd()
    class L(val x: Float, val y: Float) : PathCmd()
    class C(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val x: Float, val y: Float) : PathCmd()
    object Z : PathCmd()
}

/** Küçük SVG yol ayrıştırıcı (M L H V C S Q A Z, mutlak ve göreli). Simgeler için yeterli. */
object SvgPath {
    private fun tokens(d: String): List<Any> {
        val out = ArrayList<Any>()
        var i = 0
        val n = d.length
        while (i < n) {
            val ch = d[i]
            if (ch.isLetter() && ch != 'e' && ch != 'E') { out.add(ch); i++; continue }
            if (ch == '-' || ch == '+' || ch == '.' || ch.isDigit()) {
                var j = i
                if (d[j] == '-' || d[j] == '+') j++
                var dot = false
                while (j < n) {
                    val c = d[j]
                    if (c.isDigit()) j++
                    else if (c == '.' && !dot) { dot = true; j++ }
                    else if ((c == 'e' || c == 'E') && j + 1 < n && (d[j + 1].isDigit() || d[j + 1] == '-')) { j += 2 }
                    else break
                }
                out.add(d.substring(i, j).toFloat())
                i = j
                continue
            }
            i++
        }
        return out
    }

    fun parse(d: String): List<PathCmd> {
        val t = tokens(d)
        val out = ArrayList<PathCmd>()
        var i = 0
        var cx = 0f; var cy = 0f; var sx = 0f; var sy = 0f
        var lx = 0f; var ly = 0f; var lastC = false
        var cmd = 'M'
        fun f(): Float = (t[i++] as Float)
        while (i < t.size) {
            val tk = t[i]
            if (tk is Char) {
                cmd = tk; i++
                if (cmd == 'Z' || cmd == 'z') { out.add(PathCmd.Z); cx = sx; cy = sy; lastC = false; continue }
            }
            val rel = cmd.isLowerCase()
            when (cmd.uppercaseChar()) {
                'M' -> { val x = f(); val y = f(); cx = if (rel) cx + x else x; cy = if (rel) cy + y else y; out.add(PathCmd.M(cx, cy)); sx = cx; sy = cy; cmd = if (rel) 'l' else 'L'; lastC = false }
                'L' -> { val x = f(); val y = f(); cx = if (rel) cx + x else x; cy = if (rel) cy + y else y; out.add(PathCmd.L(cx, cy)); lastC = false }
                'H' -> { val x = f(); cx = if (rel) cx + x else x; out.add(PathCmd.L(cx, cy)); lastC = false }
                'V' -> { val y = f(); cy = if (rel) cy + y else y; out.add(PathCmd.L(cx, cy)); lastC = false }
                'C' -> {
                    var x1 = f(); var y1 = f(); var x2 = f(); var y2 = f(); var x = f(); var y = f()
                    if (rel) { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy }
                    out.add(PathCmd.C(x1, y1, x2, y2, x, y)); lx = x2; ly = y2; cx = x; cy = y; lastC = true
                }
                'S' -> {
                    var x2 = f(); var y2 = f(); var x = f(); var y = f()
                    if (rel) { x2 += cx; y2 += cy; x += cx; y += cy }
                    val x1 = if (lastC) 2 * cx - lx else cx
                    val y1 = if (lastC) 2 * cy - ly else cy
                    out.add(PathCmd.C(x1, y1, x2, y2, x, y)); lx = x2; ly = y2; cx = x; cy = y; lastC = true
                }
                'Q' -> {
                    var qx = f(); var qy = f(); var x = f(); var y = f()
                    if (rel) { qx += cx; qy += cy; x += cx; y += cy }
                    out.add(PathCmd.C(cx + 2f / 3f * (qx - cx), cy + 2f / 3f * (qy - cy), x + 2f / 3f * (qx - x), y + 2f / 3f * (qy - y), x, y))
                    cx = x; cy = y; lastC = false
                }
                'A' -> {
                    val rx = f(); val ry = f(); val rot = f(); val fa = f(); val fs = f(); var x = f(); var y = f()
                    if (rel) { x += cx; y += cy }
                    arc(out, cx, cy, rx, ry, rot, fa != 0f, fs != 0f, x, y)
                    cx = x; cy = y; lastC = false
                }
                else -> i++
            }
        }
        return out
    }

    private fun arc(out: MutableList<PathCmd>, x1: Float, y1: Float, rx0: Float, ry0: Float, rotDeg: Float, fa: Boolean, fs: Boolean, x2: Float, y2: Float) {
        if (x1 == x2 && y1 == y2) return
        var rx = abs(rx0.toDouble()); var ry = abs(ry0.toDouble())
        if (rx == 0.0 || ry == 0.0) { out.add(PathCmd.L(x2, y2)); return }
        val phi = Math.toRadians(rotDeg.toDouble()); val cp = cos(phi); val sp = sin(phi)
        val dx = (x1 - x2) / 2.0; val dy = (y1 - y2) / 2.0
        val x1p = cp * dx + sp * dy; val y1p = -sp * dx + cp * dy
        val lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
        if (lam > 1) { val s = sqrt(lam); rx *= s; ry *= s }
        val num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
        val den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
        var co = sqrt(max(0.0, num / den)); if (fa == fs) co = -co
        val cxp = co * rx * y1p / ry; val cyp = -co * ry * x1p / rx
        val cx = cp * cxp - sp * cyp + (x1 + x2) / 2.0; val cy = sp * cxp + cp * cyp + (y1 + y2) / 2.0
        val th1 = atan2((y1p - cyp) / ry, (x1p - cxp) / rx)
        val th2 = atan2((-y1p - cyp) / ry, (-x1p - cxp) / rx)
        var dth = th2 - th1
        if (fs && dth < 0) dth += 2 * PI else if (!fs && dth > 0) dth -= 2 * PI
        val n = max(1, ceil(abs(dth) / (PI / 2)).toInt())
        val d = dth / n
        val k = 4.0 / 3.0 * tan(d / 4.0)
        var th = th1
        fun px(ux: Double, uy: Double) = (cx + rx * ux * cp - ry * uy * sp).toFloat()
        fun py(ux: Double, uy: Double) = (cy + rx * ux * sp + ry * uy * cp).toFloat()
        for (s in 0 until n) {
            val c1 = cos(th); val s1 = sin(th); val c2 = cos(th + d); val s2 = sin(th + d)
            val ex = if (s == n - 1) x2 else px(c2, s2)
            val ey = if (s == n - 1) y2 else py(c2, s2)
            out.add(PathCmd.C(px(c1 - k * s1, s1 + k * c1), py(c1 - k * s1, s1 + k * c1), px(c2 + k * s2, s2 - k * c2), py(c2 + k * s2, s2 - k * c2), ex, ey))
            th += d
        }
    }
}
