package com.abert.tv

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Yedekler: (1) uygulamanın kendi klasöründe otomatik ve elle alınan son 5 yedek,
 * (2) Download/AbertTV klasörüne dışa aktarılan kopya (USB ile başka yere taşınabilir),
 * (3) ADB ile Android/data/com.abert.tv/files/ içine konan yedek dosyaları.
 */
object Backup {
    private fun dir(c: Context) = File(c.filesDir, "backups").also { it.mkdirs() }
    private fun stamp() = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())

    fun snapshot(c: Context, tag: String): String {
        val f = File(dir(c), "abert-" + stamp() + "-" + tag + ".json")
        f.writeText(Policy.exportJson(c))
        val all = dir(c).listFiles()?.filter { it.name.endsWith(".json") }?.sortedByDescending { it.lastModified() } ?: emptyList()
        all.drop(5).forEach { it.delete() }
        return f.name
    }

    /** Günde en fazla bir kez otomatik yedek. */
    fun autoSnapshot(c: Context) {
        try {
            val last = dir(c).listFiles()?.maxOfOrNull { it.lastModified() } ?: 0L
            if (System.currentTimeMillis() - last > 24 * 3600 * 1000L) snapshot(c, "oto")
        } catch (_: Throwable) { }
    }

    fun exportDownload(c: Context): String? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val name = "abert-tv-yedek-" + stamp() + ".json"
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/AbertTV")
            }
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
            c.contentResolver.openOutputStream(uri)?.use { it.write(Policy.exportJson(c).toByteArray()) }
            "Download/AbertTV/$name"
        } catch (_: Throwable) { null }
    }

    fun list(c: Context): String {
        val out = JSONArray()
        dir(c).listFiles()?.filter { it.name.endsWith(".json") }?.sortedByDescending { it.lastModified() }?.forEach {
            out.put(JSONObject().put("id", "int:" + it.name).put("name", it.name).put("t", it.lastModified()).put("src", if (it.name.contains("-oto")) "auto" else "local"))
        }
        c.getExternalFilesDir(null)?.listFiles()?.filter { it.name.endsWith(".json") }?.forEach {
            out.put(JSONObject().put("id", "ext:" + it.name).put("name", it.name).put("t", it.lastModified()).put("src", "push"))
        }
        if (Build.VERSION.SDK_INT >= 29) try {
            c.contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf("_id", "_display_name", "date_modified"),
                "relative_path LIKE ?", arrayOf("Download/AbertTV%"), "date_modified DESC")?.use { q ->
                while (q.moveToNext()) out.put(JSONObject().put("id", "dl:" + q.getLong(0)).put("name", q.getString(1)).put("t", q.getLong(2) * 1000).put("src", "download"))
            }
        } catch (_: Throwable) { }
        return out.toString()
    }

    fun read(c: Context, id: String): String? = try {
        when {
            id.startsWith("int:") -> File(dir(c), id.substring(4).substringAfterLast('/')).readText()
            id.startsWith("ext:") -> File(c.getExternalFilesDir(null), id.substring(4).substringAfterLast('/')).readText()
            id.startsWith("dl:") && Build.VERSION.SDK_INT >= 29 ->
                c.contentResolver.openInputStream(android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.substring(3).toLong()))?.use { String(it.readBytes()) }
            else -> null
        }
    } catch (_: Throwable) { null }

    /** Geri yüklemeden önce mevcut ayarlar yedeklenir, böylece geri yükleme de geri alınabilir. */
    fun restoreText(c: Context, json: String?): Boolean {
        if (json == null || json.length > 500000) return false
        try { snapshot(c, "once") } catch (_: Throwable) { }
        return Policy.importJson(c, json)
    }
}
