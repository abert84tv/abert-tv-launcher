package com.abert.tv

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray

/**
 * İSTEĞE BAĞLI tuş atama servisi. Erişilebilirlik servisleri tuşları görebildiği için ayrı tutuldu.
 * Kurallar: atanmamış tuşlar hiç işlenmeden geçirilir; hiçbir tuş kaydedilmez veya gönderilmez
 * (tek istisna: "Tuşu öğren" ekranı açıkken son tuşun kodu bellekte tutulur).
 * Çocuk ve profil seçim ekranında bu servis hiçbir tuşu yakalamaz.
 */
class KeyMapService : AccessibilityService() {
    /** press: short | long | double; prof: "" herkes, yoksa profil kimliği */
    private class Rule(val kc: Int, val sc: Int, val press: String, val prof: String, val action: String, val arg: String)

    private val handler = Handler(Looper.getMainLooper())
    private var rules: List<Rule> = emptyList()
    private var on = false
    private val active = HashMap<Int, List<Rule>>()
    private val machine = PressMachine({ ms, job -> handler.postDelayed({ job() }, ms) }) { type, k ->
        active[k]?.firstOrNull { it.press == type }?.let { run(it) }
    }
    private lateinit var prefs: SharedPreferences
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> load() }

    override fun onServiceConnected() {
        prefs = Policy.prefs(this)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        load()
    }

    override fun onDestroy() {
        try { prefs.unregisterOnSharedPreferenceChangeListener(listener) } catch (_: Throwable) { }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun load() {
        on = Policy.keyMapOn(this)
        val l = ArrayList<Rule>()
        try {
            val a = JSONArray(Policy.keymapJson(this))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val press = o.optString("press").let { if (it in setOf("short", "long", "double")) it else if (o.optBoolean("long")) "long" else "short" }
                l.add(Rule(o.optInt("kc"), o.optInt("sc"), press, o.optString("prof"), o.optString("action"), o.optString("arg")))
            }
        } catch (_: Throwable) {
        }
        rules = l
    }

    private fun isNav(k: Int) = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
        k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_CENTER ||
        k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_HOME

    private fun matches(r: Rule, e: KeyEvent) = if (r.kc == 0 || r.kc == KeyEvent.KEYCODE_UNKNOWN) e.scanCode == r.sc && r.sc != 0 else e.keyCode == r.kc

    override fun onKeyEvent(e: KeyEvent): Boolean {
        // 1) "Tuşu öğren" açıksa son tuşun kodunu bellekte tut. Gezinme tuşlarına dokunma, diğerlerini yut
        //    (böylece kumandanın Netflix gibi tuşu o sırada uygulama açmaz).
        if (Policy.learning(this)) {
            if (isNav(e.keyCode)) return false
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                Policy.setLastKey(this, "${e.keyCode}:${e.scanCode}:${KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")}")
            }
            return true
        }
        // 2) Hızlı çıkış: kapalıysa veya kural yoksa tuşa hiç dokunma.
        if (!on || rules.isEmpty()) return false
        val mode = Policy.mode(this)
        if (mode == "kids" || mode == "picker") return false
        val pid = Policy.activeId(this)
        val mine = rules.filter { matches(it, e) && (it.prof.isEmpty() || it.prof == pid) }
        // aynı basış türü için profile özel atama genel atamadan önce gelir
        val pick = listOf("short", "long", "double").mapNotNull { t -> mine.filter { it.press == t }.maxByOrNull { if (it.prof.isEmpty()) 0 else 1 } }
        if (pick.isEmpty()) {
            if (e.action == KeyEvent.ACTION_DOWN) machine.interrupt()
            return false
        }
        val id = if (e.keyCode == KeyEvent.KEYCODE_UNKNOWN || e.keyCode == 0) 100000 + e.scanCode else e.keyCode
        val hs = pick.any { it.press == "short" }; val hl = pick.any { it.press == "long" }; val hd = pick.any { it.press == "double" }
        if (e.action == KeyEvent.ACTION_DOWN) {
            active[id] = pick
            machine.down(id, e.repeatCount, hs, hl, hd)
            return true
        }
        if (e.action == KeyEvent.ACTION_UP) {
            machine.up(id, hs, hd)
            return true
        }
        return false
    }

    private fun run(r: Rule) {
        when (r.action) {
            "app" -> {
                val i = Util.launchIntent(this, r.arg) ?: return
                Policy.markLaunch(this)
                try { startActivity(i) } catch (_: Throwable) { }
            }
            "quick" -> Util.openQuick(this)
            "voice" -> Util.voice(this)
            "home" -> Util.openLauncher(this)
            "sleep" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    companion object {
        fun enabled(c: Context) = Util.a11yEnabled(c, KeyMapService::class.java)
    }
}
