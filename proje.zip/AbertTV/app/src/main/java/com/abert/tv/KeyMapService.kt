package com.abert.tv

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray

/**
 * İSTEĞE BAĞLI tuş atama servisi. Erişilebilirlik servisleri tuşları görebildiği için ayrı tutuldu.
 * Kurallar: atanmamış tuşlar hiç işlenmeden geçirilir; hiçbir tuş kaydedilmez veya gönderilmez
 * (tek istisna: "Tuşu öğren" ekranı açıkken son tuşun kodu bellekte tutulur).
 * Çocuk ve profil seçim ekranında bu servis hiçbir tuşu yakalamaz.
 */
class KeyMapService : AccessibilityService() {
    private class Rule(val kc: Int, val sc: Int, val long: Boolean, val action: String, val arg: String)

    private val handler = Handler(Looper.getMainLooper())
    private var rules: List<Rule> = emptyList()
    private var on = false
    private var downAt = 0L
    private var longFired = false
    private var pending: Runnable? = null
    private lateinit var prefs: SharedPreferences
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> load() }

    override fun onServiceConnected() {
        prefs = Policy.prefs(this)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        load()
    }

    override fun onDestroy() {
        try { prefs.unregisterOnSharedPreferenceChangeListener(listener) } catch (_: Throwable) { }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun load() {
        on = Policy.keyMapOn(this)
        val l = ArrayList<Rule>()
        try {
            val a = JSONArray(Policy.keymapJson(this))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Rule(o.optInt("kc"), o.optInt("sc"), o.optBoolean("long"), o.optString("action"), o.optString("arg")))
            }
        } catch (_: Throwable) {
        }
        rules = l
    }

    private fun isNav(k: Int) = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
        k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_CENTER ||
        k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_HOME

    private fun matches(r: Rule, e: KeyEvent) = if (r.kc == 0 || r.kc == KeyEvent.KEYCODE_UNKNOWN) e.scanCode == r.sc && r.sc != 0 else e.keyCode == r.kc

    override fun onKeyEvent(e: KeyEvent): Boolean {
        // 1) "Tuşu öğren" açıksa son tuşun kodunu bellekte tut. Gezinme tuşlarına dokunma, diğerlerini yut
        //    (böylece kumandanın Netflix gibi tuşu o sırada uygulama açmaz).
        if (Policy.learning(this)) {
            if (isNav(e.keyCode)) return false
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                Policy.setLastKey(this, "${e.keyCode}:${e.scanCode}:${KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")}")
            }
            return true
        }
        // 2) Hızlı çıkış: kapalıysa veya kural yoksa tuşa hiç dokunma.
        if (!on || rules.isEmpty()) return false
        var short: Rule? = null
        var long: Rule? = null
        for (r in rules) if (matches(r, e)) { if (r.long) long = r else short = r }
        if (short == null && long == null) return false
        val mode = Policy.mode(this)
        if (mode == "kids" || mode == "picker") return false

        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount > 0) return true
            downAt = System.currentTimeMillis()
            longFired = false
            if (long == null) {
                short?.let { run(it) }
            } else {
                val r = Runnable { longFired = true; run(long) }
                pending = r
                handler.postDelayed(r, 550)
            }
            return true
        }
        if (e.action == KeyEvent.ACTION_UP) {
            if (long != null) {
                pending?.let { handler.removeCallbacks(it) }
                pending = null
                if (!longFired) short?.let { run(it) }
            }
            return true
        }
        return false
    }

    private fun run(r: Rule) {
        when (r.action) {
            "app" -> {
                val i = Util.launchIntent(this, r.arg) ?: return
                Policy.markLaunch(this)
                try { startActivity(i) } catch (_: Throwable) { }
            }
            "quick" -> Util.openQuick(this)
            "voice" -> Util.voice(this)
            "home" -> Util.openLauncher(this)
            "sleep" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    companion object {
        fun enabled(c: Context) = Util.a11yEnabled(c, KeyMapService::class.java)
    }
}
