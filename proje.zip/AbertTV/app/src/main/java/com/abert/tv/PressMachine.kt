package com.abert.tv

/**
 * Bir tuşun kısa, uzun ve çift basışını ayırır. Android'e bağımlı değildir; bilgisayarda test edilir.
 * schedule(ms, iş): işi ms sonra çalıştırır. fire(tür, tuş): "short" | "long" | "double".
 * Kural: tuşta yalnızca kısa basış atanmışsa hiç beklemeden çalışır (gecikme yok).
 */
class PressMachine(
    private val schedule: (Long, () -> Unit) -> Unit,
    private val fire: (String, Int) -> Unit
) {
    var longMs = 550L
    var doubleMs = 320L
    private var key = Int.MIN_VALUE
    private var gen = 0
    private var longFired = false
    private var swallowUp = false
    private var waitingSecond = false
    private var pendingShort = false

    /** Başka (atanmamış) bir tuşa basılınca bekleyen kısa basış kaybolmasın. */
    fun interrupt() {
        if (waitingSecond) {
            waitingSecond = false; gen++
            if (pendingShort) fire("short", key)
        }
    }

    fun down(k: Int, repeat: Int, hasShort: Boolean, hasLong: Boolean, hasDouble: Boolean) {
        if (repeat > 0) return
        if (waitingSecond && k == key && hasDouble) {
            waitingSecond = false; gen++; swallowUp = true
            fire("double", k)
            return
        }
        if (waitingSecond) interrupt()
        key = k; longFired = false; swallowUp = false
        if (!hasLong && !hasDouble) {
            swallowUp = true
            if (hasShort) fire("short", k)
            return
        }
        if (hasLong) {
            val g = ++gen
            schedule(longMs) { if (g == gen && key == k) { longFired = true; fire("long", k) } }
        }
    }

    fun up(k: Int, hasShort: Boolean, hasDouble: Boolean) {
        if (k != key) return
        if (swallowUp) { swallowUp = false; return }
        gen++
        if (longFired) { longFired = false; return }
        if (hasDouble) {
            waitingSecond = true; pendingShort = hasShort
            val g = gen
            schedule(doubleMs) { if (g == gen && waitingSecond) { waitingSecond = false; if (pendingShort) fire("short", k) } }
            return
        }
        if (hasShort) fire("short", k)
    }
}
