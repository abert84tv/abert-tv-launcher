package com.abert.tv.ui

/** Çizim soyutlaması: aynı sahne kodu hem Android Canvas'ta hem bilgisayarda (test için) çalışır. */
interface Gfx {
    fun save()
    fun restore()
    fun translate(dx: Float, dy: Float)
    fun scale(sx: Float, sy: Float)
    /** Sonraki çizimlerin saydamlığını çarpar (restore ile geri alınır). */
    fun alpha(a: Float)
    fun clipRect(x: Float, y: Float, w: Float, h: Float)
    fun fillRect(x: Float, y: Float, w: Float, h: Float, color: Int)
    fun fillRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int)
    fun fillRRectGrad(x: Float, y: Float, w: Float, h: Float, r: Float, top: Int, bottom: Int)
    fun strokeRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int, sw: Float)
    fun fillCircle(cx: Float, cy: Float, r: Float, color: Int)
    /** Merkezden dışa doğru saydamlaşan renk (ortam ışığı). */
    fun glow(cx: Float, cy: Float, r: Float, color: Int)
    /** y taban çizgisidir. align: 0 sol, 1 orta, 2 sağ. weight: 300, 400, 600. */
    fun text(s: String, x: Float, y: Float, size: Float, color: Int, weight: Int, align: Int)
    fun measure(s: String, size: Float, weight: Int): Float
    /** 24 birimlik simge yolunu size boyutunda (sol üst x,y) boyar. */
    fun icon(cmds: List<PathCmd>, x: Float, y: Float, size: Float, color: Int)
}

object Col {
    fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
    fun a(c: Int) = (c ushr 24) and 255
    fun r(c: Int) = (c shr 16) and 255
    fun g(c: Int) = (c shr 8) and 255
    fun b(c: Int) = c and 255
    fun withAlpha(c: Int, a: Float) = argb((255 * a).toInt().coerceIn(0, 255), r(c), g(c), b(c))
    /** c rengini t oranında beyaza (t>0) veya siyaha (t<0) karıştırır. */
    fun shade(c: Int, t: Float): Int {
        val tgt = if (t >= 0) 255 else 0
        val k = Math.abs(t)
        fun m(v: Int) = (v + (tgt - v) * k).toInt().coerceIn(0, 255)
        return argb(a(c), m(r(c)), m(g(c)), m(b(c)))
    }
    fun parse(hex: String): Int {
        val h = hex.removePrefix("#")
        return (0xFF shl 24) or h.toLong(16).toInt()
    }
}
