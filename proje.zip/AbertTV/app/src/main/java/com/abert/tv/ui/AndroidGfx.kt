package com.abert.tv.ui

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

/** Gfx'in Android Canvas gerçeklemesi. Görünüm ağacı yok; her şey tek bir Canvas'a çizilir. */
class AndroidGfx(private val c: Canvas) : Gfx {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var am = 1f
    private val amStack = ArrayList<Float>()
    private val rect = RectF()
    private val tf = HashMap<Int, Typeface>()

    private fun col(color: Int): Int =
        Col.argb((Col.a(color) * am).toInt().coerceIn(0, 255), Col.r(color), Col.g(color), Col.b(color))

    private fun face(weight: Int): Typeface = tf.getOrPut(weight) {
        when (weight) {
            300 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            600 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            else -> Typeface.create("sans-serif", Typeface.NORMAL)
        }
    }

    override fun save() { c.save(); amStack.add(am) }
    override fun restore() { c.restore(); am = amStack.removeAt(amStack.size - 1) }
    override fun translate(dx: Float, dy: Float) { c.translate(dx, dy) }
    override fun scale(sx: Float, sy: Float) { c.scale(sx, sy) }
    override fun alpha(a: Float) { am *= a }
    override fun clipRect(x: Float, y: Float, w: Float, h: Float) { c.clipRect(x, y, x + w, y + h) }

    override fun fillRect(x: Float, y: Float, w: Float, h: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = col(color)
        c.drawRect(x, y, x + w, y + h, p)
    }

    override fun fillRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = col(color)
        rect.set(x, y, x + w, y + h); c.drawRoundRect(rect, r, r, p)
    }

    override fun fillRRectGrad(x: Float, y: Float, w: Float, h: Float, r: Float, top: Int, bottom: Int) {
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
        p.shader = LinearGradient(x, y, x, y + h, col(top), col(bottom), Shader.TileMode.CLAMP)
        rect.set(x, y, x + w, y + h); c.drawRoundRect(rect, r, r, p)
        p.shader = null
    }

    override fun strokeRRect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Int, sw: Float) {
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeWidth = sw; p.color = col(color)
        rect.set(x, y, x + w, y + h); c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.FILL
    }

    override fun fillCircle(cx: Float, cy: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = col(color)
        c.drawCircle(cx, cy, r, p)
    }

    override fun glow(cx: Float, cy: Float, r: Float, color: Int) {
        val c0 = col(color)
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
        p.shader = RadialGradient(cx, cy, r, c0, c0 and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
    }

    override fun text(s: String, x: Float, y: Float, size: Float, color: Int, weight: Int, align: Int) {
        p.style = Paint.Style.FILL; p.shader = null
        p.typeface = face(weight); p.textSize = size; p.color = col(color)
        p.textAlign = when (align) { 1 -> Paint.Align.CENTER; 2 -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
        c.drawText(s, x, y, p)
    }

    override fun measure(s: String, size: Float, weight: Int): Float {
        p.typeface = face(weight); p.textSize = size
        return p.measureText(s)
    }

    override fun icon(cmds: List<PathCmd>, x: Float, y: Float, size: Float, color: Int) {
        val path = Path()
        for (cmd in cmds) when (cmd) {
            is PathCmd.M -> path.moveTo(cmd.x, cmd.y)
            is PathCmd.L -> path.lineTo(cmd.x, cmd.y)
            is PathCmd.C -> path.cubicTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2, cmd.x, cmd.y)
            is PathCmd.Z -> path.close()
        }
        p.style = Paint.Style.FILL; p.shader = null; p.color = col(color)
        c.save(); c.translate(x, y); c.scale(size / 24f, size / 24f)
        c.drawPath(path, p)
        c.restore()
    }
}
