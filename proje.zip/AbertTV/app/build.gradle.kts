plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abert.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abert.tv"
        minSdk = 26
        targetSdk = 34
        versionCode = 20
        versionName = "2.11"
    }
    // Sabit imza anahtarı: her derlemede aynı imza olur, böylece güncelleme eski sürümün üstüne kurulabilir.
    // İsteğe bağlı: GitHub gizli anahtarları (ABERT_KEYSTORE vb.) tanımlıysa onlar kullanılır; yoksa depodaki anahtar.
    signingConfigs {
        getByName("debug") {
            val ks = System.getenv("ABERT_KEYSTORE")
            storeFile = if (ks.isNullOrEmpty()) file("debug.keystore") else file(ks)
            storePassword = System.getenv("ABERT_KS_PASS")?.takeIf { it.isNotEmpty() } ?: "abert-tv-debug"
            keyAlias = System.getenv("ABERT_KS_ALIAS")?.takeIf { it.isNotEmpty() } ?: "abert"
            keyPassword = System.getenv("ABERT_KEY_PASS")?.takeIf { it.isNotEmpty() } ?: "abert-tv-debug"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Bilerek hiçbir dış kütüphane yok: daha az saldırı yüzeyi, daha hızlı açılış.
dependencies { }
