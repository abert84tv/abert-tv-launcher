plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abert.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abert.tv"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    // Sabit imza anahtarı: her derlemede aynı imza olur, böylece güncelleme eski sürümün üstüne kurulabilir.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "abert-tv-debug"
            keyAlias = "abert"
            keyPassword = "abert-tv-debug"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Bilerek hiçbir dış kütüphane yok: daha az saldırı yüzeyi, daha hızlı açılış.
dependencies { }
